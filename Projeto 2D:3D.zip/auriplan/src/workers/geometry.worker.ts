/**
 * Geometry Worker - Processamento geométrico em background
 * Executa cálculos pesados fora da thread principal
 */

import type { Vec2, Wall, Room } from '@/types';
import {
  polygonArea,
  polygonCentroid,
  polygonBounds,
  polygonIsCCW,
  polygonSimplify,
  pointInPolygon,
  polygonOffset,
  wallLineIntersection,
  wallLength,
  wallCorners,
  detectRoomsFromWalls,
  v2Distance,
  v2Midpoint,
} from '@/core';

// ============================================
// TIPOS DE MENSAGEM
// ============================================

export type GeometryWorkerRequest =
  | { readonly type: 'calculateArea'; readonly points: readonly Vec2[] }
  | { readonly type: 'detectRooms'; readonly walls: readonly Wall[] }
  | { readonly type: 'simplifyPolygon'; readonly points: readonly Vec2[]; readonly tolerance?: number }
  | { readonly type: 'offsetPolygon'; readonly points: readonly Vec2[]; readonly distance: number }
  | { readonly type: 'intersectWalls'; readonly walls: readonly [Wall, Wall] }
  | { readonly type: 'pointInRoom'; readonly point: Vec2; readonly rooms: readonly Room[] };

export type GeometryWorkerResponse =
  | { readonly type: 'calculateArea'; readonly result: number }
  | { readonly type: 'detectRooms'; readonly result: { rooms: Room[]; confidence: number; warnings: string[] } }
  | { readonly type: 'simplifyPolygon'; readonly result: Vec2[] }
  | { readonly type: 'offsetPolygon'; readonly result: Vec2[] }
  | { readonly type: 'intersectWalls'; readonly result: Vec2 | null }
  | { readonly type: 'pointInRoom'; readonly result: { roomId: string | null; distance: number } }
  | { readonly type: 'error'; readonly requestType: string; readonly message: string };

// ============================================
// HANDLERS
// ============================================

const handlers: {
  readonly [K in GeometryWorkerRequest['type']]: (msg: Extract<GeometryWorkerRequest, { type: K }>) => GeometryWorkerResponse;
} = {
  calculateArea: (msg) => ({
    type: 'calculateArea',
    result: polygonArea(msg.points),
  }),

  detectRooms: (msg) => {
    const detection = detectRoomsFromWalls(msg.walls);
    return {
      type: 'detectRooms',
      result: {
        rooms: detection.rooms,
        confidence: detection.confidence,
        warnings: [...detection.warnings],
      },
    };
  },

  simplifyPolygon: (msg) => ({
    type: 'simplifyPolygon',
    result: polygonSimplify(msg.points, msg.tolerance),
  }),

  offsetPolygon: (msg) => ({
    type: 'offsetPolygon',
    result: polygonOffset(msg.points, msg.distance),
  }),

  intersectWalls: (msg) => ({
    type: 'intersectWalls',
    result: wallLineIntersection(msg.walls[0], msg.walls[1]),
  }),

  pointInRoom: (msg) => {
    let closestRoom: Room | null = null;
    let minDistance = Infinity;

    for (const room of msg.rooms) {
      if (pointInPolygon(msg.point, room.points)) {
        return { type: 'pointInRoom', result: { roomId: room.id, distance: 0 } };
      }
      const centroid = polygonCentroid(room.points);
      const dist = v2Distance(msg.point, centroid);
      if (dist < minDistance) {
        minDistance = dist;
        closestRoom = room;
      }
    }

    return {
      type: 'pointInRoom',
      result: { roomId: closestRoom?.id ?? null, distance: minDistance },
    };
  },
};

// ============================================
// WORKER LOOP
// ============================================

self.onmessage = (event: MessageEvent<GeometryWorkerRequest>) => {
  const msg = event.data;

  try {
    const handler = handlers[msg.type as keyof typeof handlers];
    if (!handler) {
      self.postMessage({
        type: 'error',
        requestType: msg.type,
        message: `Unknown request type: ${msg.type}`,
      } as GeometryWorkerResponse);
      return;
    }

    const result = (handler as (msg: GeometryWorkerRequest) => GeometryWorkerResponse)(msg);
    self.postMessage(result);
  } catch (error) {
    self.postMessage({
      type: 'error',
      requestType: msg.type,
      message: error instanceof Error ? error.message : 'Unknown error',
    } as GeometryWorkerResponse);
  }
};

// Exporta vazio para o TypeScript reconhecer como módulo
export {};
