/**
 * Snap Worker - Cálculo de snapping em background
 * Processa candidatos de snap sem bloquear a UI
 */

import type { Vec2, Wall, SnapCandidate, SnapConfig } from '@/types';
import { SNAP_PRIORITY_MAP } from '@/types/snap';
import {
  v2,
  v2DistanceSq,
  v2Distance,
  v2Midpoint,
  v2Sub,
  v2Dot,
  v2LengthSq,
  EPS,
  projectPointOnSegment,
  segmentIntersection,
  snapAngle,
  v2SnapToGrid,
} from '@/core';

// ============================================
// TIPOS DE MENSAGEM
// ============================================

export type SnapWorkerRequest = {
  readonly type: 'solveSnap';
  readonly cursor: Vec2;
  readonly walls: readonly Wall[];
  readonly config: SnapConfig;
  readonly referencePoint: Vec2 | null;
};

export type SnapWorkerResponse = {
  readonly type: 'solveSnap';
  readonly candidates: readonly SnapCandidate[];
  readonly bestCandidate: SnapCandidate | null;
} | {
  readonly type: 'error';
  readonly message: string;
};

// ============================================
// COLETORES DE CANDIDATOS
// ============================================

function collectVertexSnaps(cursor: Vec2, walls: readonly Wall[], tolSq: number): SnapCandidate[] {
  const snaps: SnapCandidate[] = [];
  const seen = new Set<string>();

  for (const wall of walls) {
    for (const point of [wall.start, wall.end]) {
      const key = `${Math.round(point[0] * 1e6)},${Math.round(point[1] * 1e6)}`;
      if (seen.has(key)) continue;
      seen.add(key);

      const distSq = v2DistanceSq(cursor, point);
      if (distSq <= tolSq) {
        snaps.push({
          type: 'vertex',
          point,
          distance: Math.sqrt(distSq),
          sourceId: wall.id,
        });
      }
    }
  }
  return snaps;
}

function collectIntersectionSnaps(cursor: Vec2, walls: readonly Wall[], tolSq: number): SnapCandidate[] {
  const snaps: SnapCandidate[] = [];
  const seen = new Set<string>();

  for (let i = 0; i < walls.length; i++) {
    for (let j = i + 1; j < walls.length; j++) {
      const p = segmentIntersection(walls[i].start, walls[i].end, walls[j].start, walls[j].end);
      if (!p) continue;

      const key = `${Math.round(p[0] * 1e6)},${Math.round(p[1] * 1e6)}`;
      if (seen.has(key)) continue;
      seen.add(key);

      const distSq = v2DistanceSq(cursor, p);
      if (distSq <= tolSq) {
        snaps.push({
          type: 'intersection',
          point: p,
          distance: Math.sqrt(distSq),
          sourceId: null,
        });
      }
    }
  }
  return snaps;
}

function collectMidpointSnaps(cursor: Vec2, walls: readonly Wall[], tolSq: number): SnapCandidate[] {
  const snaps: SnapCandidate[] = [];
  for (const wall of walls) {
    const mid = v2Midpoint(wall.start, wall.end);
    const distSq = v2DistanceSq(cursor, mid);
    if (distSq <= tolSq) {
      snaps.push({
        type: 'midpoint',
        point: mid,
        distance: Math.sqrt(distSq),
        sourceId: wall.id,
      });
    }
  }
  return snaps;
}

function collectWallSnaps(cursor: Vec2, walls: readonly Wall[], tolSq: number): SnapCandidate[] {
  const snaps: SnapCandidate[] = [];
  for (const wall of walls) {
    const proj = projectPointOnSegment(cursor, wall.start, wall.end);
    const distSq = v2DistanceSq(cursor, proj);
    if (distSq <= tolSq) {
      snaps.push({
        type: 'wall',
        point: proj,
        distance: Math.sqrt(distSq),
        sourceId: wall.id,
      });
    }
  }
  return snaps;
}

function collectGridSnaps(cursor: Vec2, config: SnapConfig): SnapCandidate[] {
  const snapped = v2SnapToGrid(cursor, config.gridSize);
  const dist = v2Distance(cursor, snapped);
  if (dist <= config.snapDistance) {
    return [{ type: 'grid', point: snapped, distance: dist, sourceId: null }];
  }
  return [];
}

function collectAngleSnaps(cursor: Vec2, referencePoint: Vec2 | null, config: SnapConfig): SnapCandidate[] {
  if (!referencePoint) return [];

  const snapped = snapAngle(referencePoint, cursor, config.angleSnap);
  const dist = v2Distance(cursor, snapped);
  if (dist <= config.snapDistance) {
    return [{ type: 'angle', point: snapped, distance: dist, sourceId: null }];
  }
  return [];
}

// ============================================
// SOLVER PRINCIPAL
// ============================================

function solveSnap(
  cursor: Vec2,
  walls: readonly Wall[],
  config: SnapConfig,
  referencePoint: Vec2 | null,
): { candidates: SnapCandidate[]; bestCandidate: SnapCandidate | null } {
  if (!config.enabled) {
    return { candidates: [], bestCandidate: null };
  }

  const tol = config.snapDistance;
  const tolSq = tol * tol;
  const allCandidates: SnapCandidate[] = [];

  // Coleta todos os tipos habilitados
  for (const snapType of config.priorities) {
    switch (snapType) {
      case 'vertex':
        allCandidates.push(...collectVertexSnaps(cursor, walls, tolSq));
        break;
      case 'intersection':
        allCandidates.push(...collectIntersectionSnaps(cursor, walls, tolSq));
        break;
      case 'midpoint':
        allCandidates.push(...collectMidpointSnaps(cursor, walls, tolSq));
        break;
      case 'wall':
        allCandidates.push(...collectWallSnaps(cursor, walls, tolSq));
        break;
      case 'grid':
        allCandidates.push(...collectGridSnaps(cursor, config));
        break;
      case 'angle':
        allCandidates.push(...collectAngleSnaps(cursor, referencePoint, config));
        break;
    }
  }

  if (allCandidates.length === 0) {
    return { candidates: [], bestCandidate: null };
  }

  // Ordena por prioridade e depois por distância
  const sorted = [...allCandidates].sort((a, b) => {
    const priorityA = SNAP_PRIORITY_MAP[a.type] ?? 99;
    const priorityB = SNAP_PRIORITY_MAP[b.type] ?? 99;
    if (priorityA !== priorityB) return priorityA - priorityB;
    return a.distance - b.distance;
  });

  return {
    candidates: sorted,
    bestCandidate: sorted[0] ?? null,
  };
}

// ============================================
// WORKER LOOP
// ============================================

self.onmessage = (event: MessageEvent<SnapWorkerRequest>) => {
  const msg = event.data;

  try {
    if (msg.type === 'solveSnap') {
      const result = solveSnap(msg.cursor, msg.walls, msg.config, msg.referencePoint);
      self.postMessage({ type: 'solveSnap', ...result } as SnapWorkerResponse);
    } else {
      self.postMessage({ type: 'error', message: `Unknown request type` } as SnapWorkerResponse);
    }
  } catch (error) {
    self.postMessage({
      type: 'error',
      message: error instanceof Error ? error.message : 'Unknown error',
    } as SnapWorkerResponse);
  }
};

export {};
