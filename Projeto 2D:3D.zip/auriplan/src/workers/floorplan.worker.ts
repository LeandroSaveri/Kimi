/**
 * FloorPlan Worker - Geração de plantas baixas em background
 * Gera layout automático de cômodos
 */

import type { Vec2, RoomType } from '@/types';
import { v2 } from '@/core';

// ============================================
// TIPOS
// ============================================

export interface FloorPlanRequest {
  readonly type: 'generateFloorPlan';
  readonly plotWidth: number;
  readonly plotDepth: number;
  readonly roomTypes: readonly RoomType[];
  readonly numBedrooms: number;
  readonly numBathrooms: number;
  readonly style: 'modern' | 'traditional' | 'minimalist' | 'open-concept';
  readonly constraints?: {
    readonly maxArea?: number;
    readonly minArea?: number;
    readonly preferredOrientation?: 'north' | 'south' | 'east' | 'west';
  };
}

export interface FloorPlanRoom {
  readonly id: string;
  readonly type: RoomType;
  readonly name: string;
  readonly points: readonly Vec2[];
  readonly area: number;
}

export interface FloorPlanResult {
  readonly type: 'floorPlanGenerated';
  readonly rooms: readonly FloorPlanRoom[];
  readonly totalArea: number;
  readonly score: number;
}

export type FloorPlanWorkerResponse =
  | FloorPlanResult
  | { readonly type: 'error'; readonly message: string };

// ============================================
// GERADORES DE LAYOUT
// ============================================

function generateModernLayout(
  width: number,
  depth: number,
  numBedrooms: number,
  numBathrooms: number,
): FloorPlanRoom[] {
  const rooms: FloorPlanRoom[] = [];
  const margin = 0.3;
  const availableW = width - margin * 2;
  const availableD = depth - margin * 2;

  // Living (área principal)
  const livingW = availableW * 0.55;
  const livingD = availableD;
  rooms.push(createRoom('living_room', 'Living Room', [
    v2(margin, margin),
    v2(margin + livingW, margin),
    v2(margin + livingW, margin + livingD),
    v2(margin, margin + livingD),
  ]));

  // Cozinha adjacente ao living
  const kitchenW = availableW - livingW - 0.15;
  const kitchenD = availableD * 0.45;
  rooms.push(createRoom('kitchen', 'Kitchen', [
    v2(margin + livingW + 0.15, margin),
    v2(margin + availableW, margin),
    v2(margin + availableW, margin + kitchenD),
    v2(margin + livingW + 0.15, margin + kitchenD),
  ]));

  // Dining entre living e kitchen
  rooms.push(createRoom('dining_room', 'Dining Room', [
    v2(margin + livingW + 0.15, margin + kitchenD + 0.15),
    v2(margin + availableW, margin + kitchenD + 0.15),
    v2(margin + availableW, margin + availableD),
    v2(margin + livingW + 0.15, margin + availableD),
  ]));

  // Quartos
  const bedStartY = margin;
  const bedAreaH = availableD / Math.max(numBedrooms, 1);

  for (let i = 0; i < numBedrooms; i++) {
    const y = bedStartY + i * bedAreaH;
    rooms.push(createRoom('bedroom', `Bedroom ${i + 1}`, [
      v2(margin, y),
      v2(margin + availableW * 0.35, y),
      v2(margin + availableW * 0.35, y + bedAreaH - 0.15),
      v2(margin, y + bedAreaH - 0.15),
    ]));
  }

  // Banheiros
  const bathW = 2.0;
  const bathD = 2.5;
  for (let i = 0; i < numBathrooms; i++) {
    const x = margin + availableW - bathW;
    const y = margin + i * (bathD + 0.2);
    rooms.push(createRoom('bathroom', `Bathroom ${i + 1}`, [
      v2(x, y),
      v2(x + bathW, y),
      v2(x + bathW, y + bathD),
      v2(x, y + bathD),
    ]));
  }

  // Hallway
  rooms.push(createRoom('hallway', 'Hallway', [
    v2(margin + availableW * 0.35 + 0.1, margin),
    v2(margin + availableW * 0.6, margin),
    v2(margin + availableW * 0.6, margin + availableD),
    v2(margin + availableW * 0.35 + 0.1, margin + availableD),
  ]));

  return rooms;
}

function generateTraditionalLayout(
  width: number,
  depth: number,
  numBedrooms: number,
  numBathrooms: number,
): FloorPlanRoom[] {
  // Layout tradicional: cômodos separados, corredor central
  const rooms: FloorPlanRoom[] = [];
  const margin = 0.3;
  const availableW = width - margin * 2;
  const availableD = depth - margin * 2;

  // Corredor central
  const hallW = 1.2;
  const hallX = margin + (availableW - hallW) / 2;

  rooms.push(createRoom('hallway', 'Main Hallway', [
    v2(hallX, margin),
    v2(hallX + hallW, margin),
    v2(hallX + hallW, margin + availableD),
    v2(hallX, margin + availableD),
  ]));

  // Living à esquerda
  rooms.push(createRoom('living_room', 'Living Room', [
    v2(margin, margin),
    v2(hallX - 0.15, margin),
    v2(hallX - 0.15, margin + availableD * 0.6),
    v2(margin, margin + availableD * 0.6),
  ]));

  // Dining à esquerda, atrás do living
  rooms.push(createRoom('dining_room', 'Dining Room', [
    v2(margin, margin + availableD * 0.6 + 0.15),
    v2(hallX - 0.15, margin + availableD * 0.6 + 0.15),
    v2(hallX - 0.15, margin + availableD),
    v2(margin, margin + availableD),
  ]));

  // Kitchen à direita
  rooms.push(createRoom('kitchen', 'Kitchen', [
    v2(hallX + hallW + 0.15, margin),
    v2(margin + availableW, margin),
    v2(margin + availableW, margin + availableD * 0.5),
    v2(hallX + hallW + 0.15, margin + availableD * 0.5),
  ]));

  // Quartos à direita
  const bedAreaD = (availableD * 0.5 - 0.15) / Math.max(numBedrooms, 1);
  for (let i = 0; i < numBedrooms; i++) {
    const y = margin + availableD * 0.5 + 0.15 + i * bedAreaD;
    rooms.push(createRoom('bedroom', `Bedroom ${i + 1}`, [
      v2(hallX + hallW + 0.15, y),
      v2(margin + availableW, y),
      v2(margin + availableW, y + bedAreaD - 0.1),
      v2(hallX + hallW + 0.15, y + bedAreaD - 0.1),
    ]));
  }

  // Banheiros
  for (let i = 0; i < numBathrooms; i++) {
    const x = margin + i * 2.2;
    rooms.push(createRoom('bathroom', `Bathroom ${i + 1}`, [
      v2(x, margin + availableD - 1.8),
      v2(x + 2.0, margin + availableD - 1.8),
      v2(x + 2.0, margin + availableD),
      v2(x, margin + availableD),
    ]));
  }

  return rooms;
}

function generateOpenConceptLayout(
  width: number,
  depth: number,
  numBedrooms: number,
  numBathrooms: number,
): FloorPlanRoom[] {
  const rooms: FloorPlanRoom[] = [];
  const margin = 0.3;
  const availableW = width - margin * 2;
  const availableD = depth - margin * 2;

  // Grande área aberta: Living + Dining + Kitchen
  const openD = availableD * 0.55;
  rooms.push(createRoom('living_room', 'Open Living Area', [
    v2(margin, margin),
    v2(margin + availableW, margin),
    v2(margin + availableW, margin + openD),
    v2(margin, margin + openD),
  ]));

  // Zona privada: quartos
  const privateY = margin + openD + 0.15;
  const privateD = availableD - openD - 0.15;

  // Quartos em fileira
  const bedW = availableW / Math.max(numBedrooms, 1);
  for (let i = 0; i < numBedrooms; i++) {
    rooms.push(createRoom('bedroom', `Bedroom ${i + 1}`, [
      v2(margin + i * bedW, privateY),
      v2(margin + (i + 1) * bedW - 0.1, privateY),
      v2(margin + (i + 1) * bedW - 0.1, privateY + privateD * 0.65),
      v2(margin + i * bedW, privateY + privateD * 0.65),
    ]));
  }

  // Banheiros
  const bathW = availableW / Math.max(numBathrooms, 1);
  for (let i = 0; i < numBathrooms; i++) {
    rooms.push(createRoom('bathroom', `Bathroom ${i + 1}`, [
      v2(margin + i * bathW, privateY + privateD * 0.65 + 0.1),
      v2(margin + (i + 1) * bathW - 0.1, privateY + privateD * 0.65 + 0.1),
      v2(margin + (i + 1) * bathW - 0.1, margin + availableD),
      v2(margin + i * bathW, margin + availableD),
    ]));
  }

  return rooms;
}

// ============================================
// UTILITÁRIOS
// ============================================

function createRoom(roomType: RoomType, name: string, points: readonly Vec2[]): FloorPlanRoom {
  // Calcula área (shoelace formula)
  let area = 0;
  const n = points.length;
  for (let i = 0; i < n; i++) {
    const j = (i + 1) % n;
    area += points[i][0] * points[j][1];
    area -= points[j][0] * points[i][1];
  }

  return {
    id: crypto.randomUUID(),
    type: roomType,
    name,
    points,
    area: Math.abs(area) / 2,
  };
}

function calculateScore(rooms: FloorPlanRoom[]): number {
  let score = 100;

  // Penaliza cômodos muito pequenos
  for (const room of rooms) {
    if (room.area < 4) score -= 10;
    if (room.area < 2) score -= 20;
  }

  // Bônus para variedade de tipos
  const types = new Set(rooms.map(r => r.type));
  score += types.size * 5;

  return Math.max(0, Math.min(100, score));
}

// ============================================
// WORKER LOOP
// ============================================

self.onmessage = (event: MessageEvent<FloorPlanRequest>) => {
  const msg = event.data;

  try {
    let rooms: FloorPlanRoom[] = [];

    switch (msg.style) {
      case 'modern':
        rooms = generateModernLayout(msg.plotWidth, msg.plotDepth, msg.numBedrooms, msg.numBathrooms);
        break;
      case 'traditional':
        rooms = generateTraditionalLayout(msg.plotWidth, msg.plotDepth, msg.numBedrooms, msg.numBathrooms);
        break;
      case 'open-concept':
        rooms = generateOpenConceptLayout(msg.plotWidth, msg.plotDepth, msg.numBedrooms, msg.numBathrooms);
        break;
      case 'minimalist':
        // Minimalista = open concept compacto
        rooms = generateOpenConceptLayout(msg.plotWidth, msg.plotDepth, msg.numBedrooms, msg.numBathrooms);
        break;
      default:
        rooms = generateModernLayout(msg.plotWidth, msg.plotDepth, msg.numBedrooms, msg.numBathrooms);
    }

    const totalArea = rooms.reduce((sum, r) => sum + r.area, 0);

    self.postMessage({
      type: 'floorPlanGenerated',
      rooms,
      totalArea,
      score: calculateScore(rooms),
    } as FloorPlanResult);
  } catch (error) {
    self.postMessage({
      type: 'error',
      message: error instanceof Error ? error.message : 'Unknown error',
    } as FloorPlanWorkerResponse);
  }
};

export {};
