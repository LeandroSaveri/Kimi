/**
 * topology.ts
 * Tipos para cache de topologia de paredes (usado pelo 3D e engine de snap)
 */

import type { Vec2 } from './core';

/** Nó do grafo de topologia (vértice onde paredes se encontram) */
export interface WallNode {
  id: string;
  position: Vec2;
  wallIds: string[];
}

/** Aresta do grafo de topologia (parede) */
export interface WallEdge {
  id: string;
  startNodeId: string;
  endNodeId: string;
  length: number;
}

/** Grafo de topologia completo de uma cena */
export interface WallTopology {
  nodes: WallNode[];
  edges: WallEdge[];
  sceneId: string;
  generatedAt: number;
}

/** Cache de topologias por sceneId */
export type TopologyCache = Record<string, WallTopology>;
