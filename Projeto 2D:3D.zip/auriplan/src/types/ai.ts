/**
 * AI Types - Tipos para processamento de linguagem natural
 * Fonte única da verdade para integração com IA
 */

/** Intenção do usuário */
export type AIIntent =
  | 'create'
  | 'add'
  | 'remove'
  | 'modify'
  | 'move'
  | 'resize'
  | 'rotate'
  | 'duplicate'
  | 'query'
  | 'style'
  | 'export'
  | 'undo'
  | 'help'
  | 'unknown';

/** Alvo da ação */
export type AITarget =
  | 'house'
  | 'room'
  | 'wall'
  | 'furniture'
  | 'floor'
  | 'ceiling'
  | 'door'
  | 'window'
  | 'light'
  | 'material'
  | 'color'
  | 'project'
  | 'layout';

/** Comando interpretado */
export interface InterpretedCommand {
  readonly intent: AIIntent;
  readonly target: AITarget;
  readonly targetType: string | null;   // ex: 'bedroom', 'sofa'
  readonly specifications: Record<string, number | string | boolean>;
  readonly location: string | null;     // ex: 'na sala', 'ao lado da cozinha'
  readonly style: string | null;
  readonly confidence: number;          // 0-1
}

/** Resultado de interpretação */
export interface InterpretationResult {
  readonly success: boolean;
  readonly command: InterpretedCommand | null;
  readonly error: string | null;
  readonly alternatives: readonly InterpretedCommand[];
}

/** Estilo de design */
export type DesignStyle =
  | 'modern'
  | 'classic'
  | 'minimalist'
  | 'industrial'
  | 'scandinavian'
  | 'bohemian'
  | 'rustic'
  | 'contemporary'
  | 'traditional'
  | 'eclectic';

/** Sugestão de design */
export interface DesignSuggestion {
  readonly roomType: string;
  readonly style: DesignStyle;
  readonly elements: readonly SuggestedElement[];
  readonly colorPalette: readonly string[];
  readonly estimatedCost: number;
}

/** Elemento sugerido */
export interface SuggestedElement {
  readonly furnitureType: string;
  readonly position: { readonly x: number; readonly y: number; readonly z: number };
  readonly rotation: number;
  readonly scale: number;
  readonly material: string | null;
  readonly color: string | null;
}

/** Análise de layout */
export interface LayoutAnalysis {
  readonly score: number;
  readonly issues: readonly LayoutIssue[];
  readonly suggestions: readonly string[];
}

/** Problema de layout */
export interface LayoutIssue {
  readonly severity: 'error' | 'warning' | 'info';
  readonly roomId: string | null;
  readonly message: string;
  readonly suggestion: string;
}
