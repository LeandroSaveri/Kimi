/**
 * Editor Types - Tipos específicos do editor visual
 * Fonte única da verdade para interação e renderização
 */

import type { Vec2, EntityId, RGBA } from './core';

/** Evento de input normalizado (mouse, touch, stylus) */
export interface EditorInputEvent {
  readonly kind: 'down' | 'move' | 'up' | 'cancel' | 'scroll' | 'dblclick' | 'longpress';
  readonly position: Vec2;           // coordenadas do mundo
  readonly screenPosition: Vec2;     // coordenadas da tela
  readonly pointerId: number;
  readonly pressure: number;         // 0-1 (para stylus)
  readonly buttons: number;          // bitmask de botões
  readonly modifiers: {
    readonly shift: boolean;
    readonly ctrl: boolean;
    readonly alt: boolean;
    readonly meta: boolean;
  };
  readonly source: 'mouse' | 'touch' | 'pen' | 'unknown';
  readonly timestamp: number;
}

/** Hit test result - o que está sob o cursor */
export interface HitTestResult {
  readonly kind: 'wall' | 'room' | 'furniture' | 'opening' | 'vertex' | 'edge' | 'grid' | 'none';
  readonly entityId: EntityId | null;
  readonly subId: string | null;     // ex: vertexId, edge index
  readonly point: Vec2;              // ponto exato do hit em coordenadas do mundo
  readonly distance: number;         // distância em px da tela
  readonly normal: Vec2 | null;      // normal da superfície (para paredes)
}

/** Estado de renderização do canvas 2D */
export interface Render2DState {
  readonly canvas: HTMLCanvasElement | null;
  readonly ctx: CanvasRenderingContext2D | null;
  readonly isDirty: boolean;
  readonly animating: boolean;
  readonly frameCount: number;
  readonly lastFrameTime: number;
  readonly fps: number;
}

/** Estado de renderização 3D */
export interface Render3DState {
  readonly canvas: HTMLCanvasElement | null;
  readonly gl: WebGLRenderingContext | null;
  readonly sceneReady: boolean;
  readonly camera: {
    readonly position: import('./core').Vec3;
    readonly target: import('./core').Vec3;
    readonly up: import('./core').Vec3;
    readonly fov: number;
  };
}

/** Estilo visual de parede */
export interface WallRenderStyle {
  readonly strokeColor: RGBA;
  readonly fillColor: RGBA;
  readonly selectedColor: RGBA;
  readonly hoverColor: RGBA;
  readonly strokeWidth: number;      // em pixels da tela
  readonly selectedWidth: number;
}

/** Estilo visual de cômodo */
export interface RoomRenderStyle {
  readonly fillColor: RGBA;
  readonly strokeColor: RGBA;
  readonly selectedFill: RGBA;
  readonly hoverFill: RGBA;
  readonly strokeWidth: number;
  readonly showLabel: boolean;
  readonly labelColor: RGBA;
  readonly labelFontSize: number;
}

/** Estilo visual de móvel */
export interface FurnitureRenderStyle {
  readonly fillColor: RGBA;
  readonly strokeColor: RGBA;
  readonly selectedFill: RGBA;
  readonly strokeWidth: number;
  readonly showLabel: boolean;
}

/** Estilo visual de grid */
export interface GridRenderStyle {
  readonly majorColor: RGBA;
  readonly minorColor: RGBA;
  readonly axisColor: RGBA;
  readonly majorSpacing: number;     // em metros
  readonly minorSpacing: number;     // em metros
  readonly showLabels: boolean;
}

/** Configuração completa de temas */
export interface EditorTheme {
  readonly background: RGBA;
  readonly grid: GridRenderStyle;
  readonly wall: WallRenderStyle;
  readonly room: RoomRenderStyle;
  readonly furniture: FurnitureRenderStyle;
  readonly snapIndicator: {
    readonly color: RGBA;
    readonly size: number;
  };
  readonly selectionBox: {
    readonly strokeColor: RGBA;
    readonly fillColor: RGBA;
    readonly strokeWidth: number;
  };
}

/** Modo de visualização */
export type ViewMode = '2d' | '3d' | 'split';

/** Estado do modo de visualização */
export interface ViewModeState {
  readonly current: ViewMode;
  readonly splitRatio: number;       // 0-1, proporção do painel 2D
}

/** Constraint de dimensão */
export interface DimensionConstraint {
  readonly id: EntityId;
  readonly startPoint: Vec2;
  readonly endPoint: Vec2;
  readonly value: number;
  readonly unit: string;
  readonly locked: boolean;
}

/** Estado de drag em andamento */
export interface DragState {
  readonly active: boolean;
  readonly entityId: EntityId | null;
  readonly startPoint: Vec2;
  readonly currentPoint: Vec2;
  readonly delta: Vec2;
  readonly snapResult: import('./snap').SnapResult | null;
}

/** Feedback visual temporário */
export interface VisualFeedback {
  readonly id: string;
  readonly type: 'flash' | 'pulse' | 'trail' | 'ghost';
  readonly position: Vec2;
  readonly color: RGBA;
  readonly duration: number;         // ms
  readonly createdAt: number;
}

/** Modo de criação de cômodo */
export type RoomCreationMode = 'corners' | 'rectangle' | 'circle' | 'polygon';

/** Estado de criação de cômodo */
export interface RoomCreationState {
  readonly mode: RoomCreationMode;
  readonly points: readonly Vec2[];
  readonly previewPolygon: readonly Vec2[] | null;
  readonly isValid: boolean;
  readonly errorMessage: string | null;
}

/** Modo de criação de parede */
export type WallCreationMode = 'segment' | 'chain' | 'rectangle' | 'continuous';

/** Estado de criação de parede */
export interface WallCreationState {
  readonly mode: WallCreationMode;
  readonly startPoint: Vec2 | null;
  readonly previewEnd: Vec2 | null;
  readonly segments: readonly { start: Vec2; end: Vec2 }[];
  readonly isOrthogonal: boolean;
}
