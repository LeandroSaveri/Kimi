/**
 * Core Types - Tipos geometricos e base do sistema
 * Fonte unica da verdade para todos os tipos
 * Todos os tipos usados por store, core, engine e features
 */

// ============================================
// VETORES E PONTOS
// ============================================

/** Vetor 2D - tupla [x, y] */
export type Vec2 = [number, number];

/** Vetor 3D - tupla [x, y, z] */
export type Vec3 = [number, number, number];

/** Ponto 2D com propriedades nomeadas */
export interface Point2D {
  x: number;
  y: number;
}

/** Ponto 3D com propriedades nomeadas */
export interface Point3D extends Point2D {
  z: number;
}

/** Bounding box 2D */
export interface Bounds2D {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
  width: number;
  height: number;
  center: Vec2;
}

// ============================================
// CORES
// ============================================

/** Cor RGBA */
export interface RGBA {
  r: number;
  g: number;
  b: number;
  a: number;
}

// ============================================
// ENTIDADES GEOMETRICAS
// ============================================

/** Dimencoes de um objeto */
export interface Dimensions {
  width: number;
  height: number;
  depth?: number;
}

// ============================================
// PAREDE
// ============================================

/** Tipo de parede */
export type WallType = 'interior' | 'exterior' | 'load-bearing' | 'partition';

/** Parede */
export interface Wall {
  id: string;
  type: 'wall';
  start: Vec2;
  end: Vec2;
  thickness: number;
  height: number;
  metadata?: Record<string, unknown>;
}

// ============================================
// CÔMODO
// ============================================

/** Cômido (Room) */
export interface Room {
  id: string;
  type: 'room';
  name: string;
  points: Vec2[];
  area?: number;
  perimeter?: number;
  walls?: string[]; // IDs das paredes
  metadata?: Record<string, unknown>;
}

// ============================================
// PORTA E JANELA
// ============================================

/** Porta */
export interface Door {
  id: string;
  wallId: string;
  position: number; // 0-1 ao longo da parede
  width: number;
  height: number;
  swing?: 'left' | 'right';
}

/** Janela */
export interface Window {
  id: string;
  wallId: string;
  position: number; // 0-1 ao longo da parede
  width: number;
  height: number;
  sillHeight: number;
}

// ============================================
// MOVEL
// ============================================

/** Movel */
export interface Furniture {
  id: string;
  type: string;
  name: string;
  position: [number, number, number]; // x, y, z
  rotation: number;
  dimensions: Dimensions;
  roomId?: string;
  metadata?: Record<string, unknown>;
}

// ============================================
// MEDICAO
// ============================================

/** Medicao dimensional */
export interface Measurement {
  id: string;
  start: Vec2;
  end: Vec2;
  value: number;
  unit: string;
}

// ============================================
// CENA
// ============================================

/** Cena/planta de um pavimento */
export interface Scene {
  id: string;
  name: string;
  level: number;
  height: number;
  walls: Wall[];
  rooms: Room[];
  doors: Door[];
  windows: Window[];
  furniture: Furniture[];
  measurements: Measurement[];
  metadata?: Metadata;
  visible?: boolean;
  locked?: boolean;
  annotations?: Annotation[];
}

/** Metadados de cena */
export interface Metadata {
  [key: string]: unknown;
}

/** Anotacao */
export interface Annotation {
  id: string;
  text: string;
  position: Vec2;
}

// ============================================
// PROJETO
// ============================================

/** Projeto completo */
export interface Project {
  id: string;
  name: string;
  description: string;
  owner: User;
  createdAt: string;
  updatedAt: string;
  metadata?: Metadata;
}

/** Usuario */
export interface User {
  id: string;
  name: string;
  email: string;
  role?: string;
}

// ============================================
// ESTADO DA UI
// ============================================

/** Modo de visualizacao */
export type ViewMode = '2d' | '3d' | 'split';

/** Ferramenta ativa */
export type Tool = 'select' | 'wall' | 'room' | 'door' | 'window' | 
                   'furniture' | 'measure' | 'pan' | 'eraser' | 
                   'text' | 'dimension' | 'move' | 'rotate';

/** Estado da camera */
export interface CameraState {
  x: number;
  y: number;
  zoom: number;
  rotation: number;
}

/** Configuracao do grid */
export interface GridSettings {
  visible: boolean;
  size: number;
  color: string;
  opacity: number;
}

/** Configuracao do snap */
export interface SnapSettings {
  enabled: boolean;
  grid: boolean;
  endpoints: boolean;
  midpoints: boolean;
  edges: boolean;
  centers: boolean;
  perpendicular: boolean;
  angle: boolean;
  distance: number;
}
