/**
 * Project Types - Tipos de projeto e persistência
 * Fonte única da verdade para projetos
 */

import type { BaseEntity, EntityId, Timestamp } from './core';

/** Status do projeto */
export type ProjectStatus = 'active' | 'archived' | 'deleted' | 'template';

/** Projeto completo - raiz da hierarquia de dados */
export interface Project extends BaseEntity {
  readonly type: 'project';
  readonly name: string;
  readonly description: string;
  readonly status: ProjectStatus;
  /** ID do usuário dono */
  readonly userId: EntityId;
  /** Dados do projeto (referências por ID) */
  readonly data: ProjectData;
  /** URL da thumbnail */
  readonly thumbnailUrl: string | null;
  /** Configurações do projeto */
  readonly settings: ProjectSettings;
  /** Metadados */
  readonly metadata: ProjectMetadata;
}

/** Dados do projeto - apenas IDs, não objetos aninhados */
export interface ProjectData {
  readonly wallIds: readonly EntityId[];
  readonly roomIds: readonly EntityId[];
  readonly furnitureIds: readonly EntityId[];
  readonly openingIds: readonly EntityId[];
  readonly zoneIds: readonly EntityId[];
}

/** Configurações do projeto */
export interface ProjectSettings {
  readonly units: 'metric' | 'imperial';
  readonly precision: number;           // casas decimais
  readonly gridSize: number;            // metros
  readonly gridVisible: boolean;
  readonly snapEnabled: boolean;
  readonly angleSnap: number;           // graus
  readonly defaultWallHeight: number;   // metros
  readonly defaultWallThickness: number; // metros
  readonly ceilingHeight: number;       // metros
  readonly showDimensions: boolean;
  readonly showArea: boolean;
  readonly autoSave: boolean;
  readonly autoSaveInterval: number;    // ms
  readonly theme: 'light' | 'dark' | 'system';
  readonly language: string;
}

/** Metadados do projeto */
export interface ProjectMetadata {
  readonly totalArea: number;           // m² calculado
  readonly totalWalls: number;
  readonly totalRooms: number;
  readonly totalFurniture: number;
  readonly estimatedCost: number | null;
  readonly tags: readonly string[];
  readonly clientName: string | null;
  readonly projectAddress: string | null;
  readonly notes: string | null;
}

/** Estado completo do editor (para serialização/histórico) */
export interface EditorState {
  readonly project: Project;
  /** Mapa de todas as entidades por ID - fonte única da verdade */
  readonly entities: EntityMap;
  /** Ordem de renderização das camadas */
  readonly layerOrder: readonly EntityId[];
  /** Estado da viewport */
  readonly viewport: ViewportState;
  /** Estado da ferramenta */
  readonly tool: ToolState;
  /** Estado de seleção */
  readonly selection: SelectionState;
}

/** Mapa unificado de todas as entidades */
export interface EntityMap {
  readonly walls: ReadonlyMap<EntityId, import('./wall').Wall>;
  readonly rooms: ReadonlyMap<EntityId, import('./room').Room>;
  readonly furniture: ReadonlyMap<EntityId, import('./furniture').Furniture>;
  readonly openings: ReadonlyMap<EntityId, import('./wall').WallOpening>;
  readonly zones: ReadonlyMap<EntityId, import('./room').RoomZone>;
}

/** Estado da viewport/câmera */
export interface ViewportState {
  readonly centerX: number;
  readonly centerY: number;
  readonly zoom: number;
  readonly rotation: number;            // rotação da view em graus
  readonly width: number;               // largura do canvas em px
  readonly height: number;              // altura do canvas em px
  readonly devicePixelRatio: number;
}

/** Ferramenta ativa do editor */
export type ToolType =
  | 'select'
  | 'wall'
  | 'room'
  | 'furniture'
  | 'opening'
  | 'measure'
  | 'pan'
  | 'zoom'
  | 'eraser'
  | 'text'
  | 'dimension'
  | 'move'
  | 'rotate';

/** Modo de interação */
export type InteractionMode = 'design' | 'assemble' | 'view';

/** Estado da ferramenta */
export interface ToolState {
  readonly current: ToolType;
  readonly previous: ToolType | null;
  readonly mode: InteractionMode;
  /** Sub-modo para ferramentas complexas */
  readonly subMode: string | null;
  /** Dados transitórios da ferramenta */
  readonly transient: Record<string, unknown> | null;
}

/** Estado de seleção */
export interface SelectionState {
  /** IDs selecionados */
  readonly ids: readonly EntityId[];
  /** Tipo da seleção */
  readonly kind: 'single' | 'multi' | 'box' | 'none';
  /** Ponto de ancoragem (para operações) */
  readonly anchor: import('./core').Vec2 | null;
  /** Bounding box da seleção em coordenadas do mundo */
  readonly bounds: import('./core').Bounds | null;
}

/** Operação batch para histórico */
export interface OperationBatch {
  readonly id: string;
  readonly timestamp: Timestamp;
  readonly label: string;
  readonly operations: readonly Operation[];
  readonly inverse: readonly Operation[];
}

/** Operação unificada */
export type Operation =
  | (import('./wall').WallOperation & { readonly entityType: 'wall' })
  | (import('./room').RoomOperation & { readonly entityType: 'room' })
  | (import('./furniture').FurnitureOperation & { readonly entityType: 'furniture' });

/** Histórico de operações */
export interface HistoryState {
  readonly past: readonly OperationBatch[];
  readonly future: readonly OperationBatch[];
  readonly maxSize: number;
  readonly canUndo: boolean;
  readonly canRedo: boolean;
}

/** Template de projeto */
export interface ProjectTemplate {
  readonly id: EntityId;
  readonly name: string;
  readonly description: string;
  readonly thumbnailUrl: string | null;
  readonly category: 'residential' | 'commercial' | 'industrial' | 'outdoor';
  readonly initialState: EditorState;
  readonly tags: readonly string[];
}
