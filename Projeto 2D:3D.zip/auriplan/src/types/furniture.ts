/**
 * Furniture Types - Tipos de móveis e objetos
 * Fonte única da verdade para móveis e decoração
 */

import type { BaseEntity, Vec2, Vec3, EntityId, Dimensions } from './core';

/** Categoria de móvel */
export type FurnitureCategory =
  | 'seating'
  | 'table'
  | 'storage'
  | 'bed'
  | 'lighting'
  | 'appliance'
  | 'decor'
  | 'electronics'
  | 'plant'
  | 'rug'
  | 'curtain'
  | 'art'
  | 'mirror'
  | 'kitchen-cabinet'
  | 'countertop'
  | 'sink'
  | 'shower'
  | 'toilet'
  | 'vanity'
  | 'other';

/** Tipo específico de móvel */
export type FurnitureType =
  | 'sofa'
  | 'armchair'
  | 'dining-chair'
  | 'office-chair'
  | 'bench'
  | 'ottoman'
  | 'dining-table'
  | 'coffee-table'
  | 'side-table'
  | 'desk'
  | 'console-table'
  | 'wardrobe'
  | 'dresser'
  | 'bookshelf'
  | 'tv-stand'
  | 'cabinet'
  | 'nightstand'
  | 'bed-single'
  | 'bed-double'
  | 'bed-queen'
  | 'bed-king'
  | 'bunk-bed'
  | 'ceiling-light'
  | 'wall-light'
  | 'floor-lamp'
  | 'table-lamp'
  | 'pendant'
  | 'chandelier'
  | 'refrigerator'
  | 'stove'
  | 'oven'
  | 'microwave'
  | 'dishwasher'
  | 'washing-machine'
  | 'dryer'
  | 'tv'
  | 'computer'
  | 'speaker'
  | 'plant-small'
  | 'plant-medium'
  | 'plant-large'
  | 'rug-small'
  | 'rug-medium'
  | 'rug-large'
  | 'painting'
  | 'mirror'
  | 'vase'
  | 'clock'
  | 'other';

/** Móvel/objeto no projeto */
export interface Furniture extends BaseEntity {
  readonly type: 'furniture';
  readonly furnitureType: FurnitureType;
  readonly category: FurnitureCategory;
  readonly name: string;
  /** Posição 3D no mundo (x, y=altura, z) */
  readonly position: Vec3;
  /** Rotação em graus ao redor do eixo Y */
  readonly rotation: number;
  /** Escala */
  readonly scale: Vec3;
  /** Dimensões originais em metros */
  readonly dimensions: Dimensions;
  /** ID do cômodo onde está */
  readonly roomId: EntityId | null;
  /** Material */
  readonly material: string | null;
  /** Cor */
  readonly color: string | null;
  /** Visível */
  readonly visible: boolean;
  /** Fixado ao chão (não pode ser movido verticalmente) */
  readonly fixedToFloor: boolean;
  /** Fixado à parede */
  readonly fixedToWall: boolean;
  /** ID da parede onde está fixado (se fixedToWall) */
  readonly attachedWallId: EntityId | null;
}

/** Catálogo de móveis disponíveis */
export interface FurnitureCatalogItem {
  readonly id: string;
  readonly furnitureType: FurnitureType;
  readonly category: FurnitureCategory;
  readonly name: string;
  readonly dimensions: Dimensions;
  readonly thumbnailUrl: string | null;
  readonly modelUrl: string | null;
  readonly defaultMaterial: string | null;
  readonly defaultColor: string | null;
  readonly price: number | null;
  readonly tags: readonly string[];
}

/** Operação em móvel */
export type FurnitureOperation =
  | { readonly kind: 'create'; readonly furniture: Furniture }
  | { readonly kind: 'update'; readonly furnitureId: EntityId; readonly previous: Partial<Furniture>; readonly next: Partial<Furniture> }
  | { readonly kind: 'delete'; readonly furniture: Furniture }
  | { readonly kind: 'move'; readonly furnitureId: EntityId; readonly newPosition: Vec3 }
  | { readonly kind: 'rotate'; readonly furnitureId: EntityId; readonly newRotation: number };
