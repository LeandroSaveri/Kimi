/**
 * Wall Types - Tipos de paredes e elementos estruturais
 * Fonte única da verdade para tudo relacionado a paredes
 */

import type { BaseEntity, Vec2, EntityId } from './core';

/** Tipo de parede */
export type WallType = 'interior' | 'exterior' | 'load-bearing' | 'partition';

/** Espessura padrão por tipo de parede (em metros) */
export const WALL_THICKNESS: Record<WallType, number> = {
  exterior: 0.2,
  'load-bearing': 0.19,
  interior: 0.14,
  partition: 0.09,
};

/** Altura padrão de parede (em metros) */
export const DEFAULT_WALL_HEIGHT = 2.8;

/** Parede - elemento estrutural fundamental */
export interface Wall extends BaseEntity {
  readonly type: 'wall';
  readonly wallType: WallType;
  readonly start: Vec2;
  readonly end: Vec2;
  readonly thickness: number;
  readonly height: number;
  /** ID do cômodo à esquerda (direção start->end) */
  readonly leftRoomId: EntityId | null;
  /** ID do cômodo à direita (direção start->end) */
  readonly rightRoomId: EntityId | null;
  /** IDs de aberturas (portas, janelas) nesta parede */
  readonly openingIds: readonly EntityId[];
  /** Material do lado esquerdo */
  readonly leftMaterial: string | null;
  /** Material do lado direito */
  readonly rightMaterial: string | null;
  /** Cor/especificações de pintura */
  readonly color: string | null;
}

/** Tipo de abertura */
export type OpeningType = 'door' | 'window' | 'sliding-door' | 'arch' | 'pass-through';

/** Abertura em parede (porta, janela, etc.) */
export interface WallOpening extends BaseEntity {
  readonly type: 'opening';
  readonly openingType: OpeningType;
  /** ID da parede pai */
  readonly wallId: EntityId;
  /** Posição ao longo da parede (0 = start, 1 = end) */
  readonly position: number;
  /** Largura da abertura em metros */
  readonly width: number;
  /** Altura da abertura em metros */
  readonly height: number;
  /** Altura do peitoril (para janelas) */
  readonly sillHeight: number;
  /** Direção de abertura (para portas): 'left' | 'right' | 'both' | null */
  readonly swingDirection: 'left' | 'right' | 'both' | null;
  /** Moldura/frame */
  readonly hasFrame: boolean;
  /** Material do frame */
  readonly frameMaterial: string | null;
}

/** Vértice (canto) onde paredes se encontram */
export interface WallVertex {
  readonly id: EntityId;
  readonly position: Vec2;
  /** IDs das paredes conectadas a este vértice */
  readonly connectedWallIds: readonly EntityId[];
}

/** Informações topológicas do grafo de paredes */
export interface WallTopology {
  readonly vertices: ReadonlyMap<EntityId, WallVertex>;
  /** Adjacência: vertexId -> wallIds conectados */
  readonly adjacency: ReadonlyMap<EntityId, readonly EntityId[]>;
  /** Componentes conectados (grupos de paredes isoladas) */
  readonly components: readonly (readonly EntityId[])[];
}

/** Operação em parede para histórico */
export type WallOperation =
  | { readonly kind: 'create'; readonly wall: Wall }
  | { readonly kind: 'update'; readonly wallId: EntityId; readonly previous: Partial<Wall>; readonly next: Partial<Wall> }
  | { readonly kind: 'delete'; readonly wall: Wall }
  | { readonly kind: 'split'; readonly originalWallId: EntityId; readonly newWalls: readonly Wall[] }
  | { readonly kind: 'merge'; readonly wallIds: readonly EntityId[]; readonly mergedWall: Wall };

/** Snap de parede - usado pela engine de snap */
export interface WallSnapTarget {
  readonly kind: 'wall';
  readonly wallId: EntityId;
  readonly point: Vec2;
  /** 0-1 ao longo da parede */
  readonly t: number;
  /** Distância perpendicular projetada */
  readonly projectedDistance: number;
}

/** Snap de vértice */
export interface VertexSnapTarget {
  readonly kind: 'vertex';
  readonly vertexId: EntityId;
  readonly point: Vec2;
}

/** Snap de grid */
export interface GridSnapTarget {
  readonly kind: 'grid';
  readonly point: Vec2;
  readonly gridSize: number;
}

/** Snap de ângulo reto */
export interface AngleSnapTarget {
  readonly kind: 'angle';
  readonly point: Vec2;
  readonly angle: number;
  readonly referencePoint: Vec2;
}

/** Alinhamento de snap */
export interface AlignmentSnapTarget {
  readonly kind: 'alignment';
  readonly point: Vec2;
  readonly alignment: 'horizontal' | 'vertical';
  readonly referenceY: number | null;
  readonly referenceX: number | null;
}
