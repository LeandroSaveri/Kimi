/**
 * Snap Types - Tipos do sistema de snap magnético
 * Fonte única da verdade para snapping
 */

import type { Vec2, EntityId } from './core';
import type { Wall, WallVertex } from './wall';

/** Tipo de snap */
export type SnapType =
  | 'vertex'
  | 'intersection'
  | 'midpoint'
  | 'wall'
  | 'angle'
  | 'grid'
  | 'alignment'
  | 'distance'
  | 'none';

/** Resultado de uma operação de snap */
export interface SnapResult {
  readonly type: SnapType;
  readonly point: Vec2;
  /** Ponto original antes do snap */
  readonly originalPoint: Vec2;
  /** Entidade fonte do snap */
  readonly sourceId: EntityId | null;
  /** Prioridade (menor = mais prioritário) */
  readonly priority: number;
  /** Distância em metros */
  readonly distance: number;
  /** Indicador visual */
  readonly indicator: SnapIndicator | null;
}

/** Indicador visual de snap */
export interface SnapIndicator {
  readonly shape: 'circle' | 'cross' | 'line' | 'diamond';
  readonly position: Vec2;
  readonly color: string;
  readonly size: number;
  /** Informação adicional (ex: ângulo, distância) */
  readonly label: string | null;
}

/** Configuração do sistema de snap */
export interface SnapConfig {
  readonly enabled: boolean;
  readonly snapDistance: number;      // metros - raio de busca
  readonly gridSize: number;          // metros
  readonly angleSnap: number;         // graus
  readonly prioritizeOrthogonal: boolean;
  readonly showIndicators: boolean;
  /** Prioridades de tipos de snap */
  readonly priorities: readonly SnapType[];
}

/** Configuração padrão de snap */
export const DEFAULT_SNAP_CONFIG: SnapConfig = {
  enabled: true,
  snapDistance: 0.25,
  gridSize: 0.1,
  angleSnap: 15,
  prioritizeOrthogonal: true,
  showIndicators: true,
  priorities: ['vertex', 'intersection', 'midpoint', 'wall', 'alignment', 'grid', 'angle'],
};

/** Candidato de snap encontrado */
export interface SnapCandidate {
  readonly type: SnapType;
  readonly point: Vec2;
  readonly distance: number;
  readonly sourceId: EntityId | null;
}

/** Estado do solver de snap */
export interface SnapSolverState {
  readonly config: SnapConfig;
  readonly walls: readonly Wall[];
  readonly vertices: ReadonlyMap<EntityId, WallVertex>;
  /** Ponto de referência para snap angular/direcional */
  readonly referencePoint: Vec2 | null;
}

/** Prioridades numéricas de snap */
export const SNAP_PRIORITY_MAP: Record<SnapType, number> = {
  vertex: 1,
  intersection: 2,
  midpoint: 3,
  wall: 4,
  alignment: 5,
  grid: 6,
  angle: 7,
  distance: 8,
  none: 99,
};

/** Cores para cada tipo de snap */
export const SNAP_COLORS: Record<SnapType, string> = {
  vertex: '#22c55e',      // verde
  intersection: '#eab308', // amarelo
  midpoint: '#3b82f6',    // azul
  wall: '#6b7280',        // cinza
  angle: '#a855f7',       // roxo
  grid: '#9ca3af',        // cinza claro
  alignment: '#f97316',   // laranja
  distance: '#06b6d4',    // ciano
  none: '#000000',
};
