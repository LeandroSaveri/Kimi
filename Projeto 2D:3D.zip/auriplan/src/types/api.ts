/**
 * API Types - Tipos para comunicação com o backend
 * Fonte única da verdade para contratos de API
 * Base URL: https://auriplanoriginal-server.onrender.com
 */

import type { EntityId } from './core';

// ============================================
// RESPOSTAS PADRÃO
// ============================================

/** Resposta padronizada da API */
export interface ApiResponse<T> {
  readonly success: boolean;
  readonly data: T | null;
  readonly error: ApiError | null;
  readonly meta: ResponseMeta | null;
}

/** Erro da API */
export interface ApiError {
  readonly code: string;
  readonly message: string;
  readonly details: Record<string, string[]> | null;
  readonly status: number;
}

/** Metadados de resposta */
export interface ResponseMeta {
  readonly page: number;
  readonly limit: number;
  readonly total: number;
  readonly totalPages: number;
}

// ============================================
// AUTENTICAÇÃO
// ============================================

/** Dados de registro */
export interface RegisterRequest {
  readonly name: string;
  readonly email: string;
  readonly password: string;
}

/** Dados de login */
export interface LoginRequest {
  readonly email: string;
  readonly password: string;
}

/** Resposta de autenticação */
export interface AuthResponse {
  readonly user: UserDto;
  readonly token: string;
  readonly expiresAt: number;
}

/** Usuário no formato do backend */
export interface UserDto {
  readonly id: EntityId;
  readonly name: string;
  readonly email: string;
  readonly role: 'user' | 'admin';
  readonly isActive: boolean;
  readonly subscription: SubscriptionDto | null;
}

/** Assinatura */
export interface SubscriptionDto {
  readonly plan: 'free' | 'pro' | 'enterprise';
  readonly status: string;
  readonly currentPeriodEnd: string;
  readonly cancelAtPeriodEnd: boolean;
}

/** Trocar senha */
export interface ChangePasswordRequest {
  readonly currentPassword: string;
  readonly newPassword: string;
}

// ============================================
// PROJETOS
// ============================================

/** DTO de projeto (formato do backend) */
export interface ProjectDto {
  readonly id: EntityId;
  readonly name: string;
  readonly description: string | null;
  readonly data: Record<string, unknown>;
  readonly thumbnailUrl: string | null;
  readonly isArchived: boolean;
  readonly createdAt: string;
  readonly updatedAt: string;
}

/** Criar projeto */
export interface CreateProjectRequest {
  readonly name: string;
  readonly description?: string;
  readonly data?: Record<string, unknown>;
}

/** Atualizar projeto */
export interface UpdateProjectRequest {
  readonly name?: string;
  readonly description?: string;
  readonly data?: Record<string, unknown>;
  readonly thumbnailUrl?: string;
  readonly isArchived?: boolean;
}

/** Listar projetos */
export interface ListProjectsResponse {
  readonly projects: readonly ProjectDto[];
  readonly total: number;
  readonly page: number;
  readonly totalPages: number;
}

/** Parâmetros de listagem */
export interface ListProjectsParams {
  readonly page?: number;
  readonly limit?: number;
  readonly includeArchived?: boolean;
}

// ============================================
// QUOTAS
// ============================================

/** Status de quotas */
export interface QuotaStatus {
  readonly plan: string;
  readonly quotas: {
    readonly projects: { readonly used: number; readonly limit: number; readonly available: number };
    readonly storage: { readonly used: number; readonly limit: number; readonly available: number };
  };
  readonly features: readonly string[];
}

/** Verificação de quota */
export interface QuotaCheck {
  readonly allowed: boolean;
  readonly current: number;
  readonly limit: number;
  readonly reason: string | null;
}

// ============================================
// ASSINATURAS
// ============================================

/** Plano disponível */
export interface PlanDto {
  readonly id: string;
  readonly name: string;
  readonly quotas: {
    readonly maxProjects: number;
    readonly maxStorageMB: number;
    readonly features: readonly string[];
  };
}

/** Criar assinatura */
export interface CreateSubscriptionRequest {
  readonly planId: string;
  readonly paymentMethodId?: string;
}

// ============================================
// AI - NOVA ROTA
// ============================================

/** Request para comando de IA */
export interface AICommandRequest {
  readonly command: string;
  readonly context: AICommandContext | null;
  readonly language: string;
}

/** Contexto do editor para IA */
export interface AICommandContext {
  readonly projectId: EntityId | null;
  readonly currentRoomType: string | null;
  readonly existingRoomTypes: readonly string[];
  readonly totalArea: number;
  readonly dimensions: { readonly width: number; readonly height: number } | null;
}

/** Resposta de comando de IA */
export interface AICommandResponse {
  readonly actions: readonly EditorAction[];
  readonly message: string | null;
  readonly confidence: number;
  readonly suggestedCommands: readonly string[] | null;
}

/** Ação do editor gerada por IA */
export interface EditorAction {
  readonly type: 'createWall' | 'createRoom' | 'createFurniture' | 'updateWall' | 'updateRoom' | 'moveFurniture' | 'deleteElement' | 'loadFloorPlan';
  readonly payload: Record<string, unknown>;
  readonly description: string;
  readonly metadata: {
    readonly source: 'ai';
    readonly confidence: number;
    readonly timestamp: number;
  };
}

// ============================================
// HEALTH
// ============================================

/** Status de saúde do backend */
export interface HealthStatus {
  readonly status: 'ok' | 'error';
  readonly database: 'connected' | 'disconnected';
  readonly timestamp: string;
}
