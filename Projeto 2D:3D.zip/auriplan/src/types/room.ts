/**
 * Room Types - Tipos de cômodos e espaços
 * Fonte única da verdade para tudo relacionado a cômodos
 */

import type { BaseEntity, Vec2, EntityId, Polygon } from './core';

/** Tipo de cômodo/cômodo */
export type RoomType =
  | 'living_room'
  | 'bedroom'
  | 'master_bedroom'
  | 'kitchen'
  | 'dining_room'
  | 'bathroom'
  | 'half_bath'
  | 'office'
  | 'hallway'
  | 'entryway'
  | 'closet'
  | 'laundry'
  | 'garage'
  | 'balcony'
  | 'terrace'
  | 'pantry'
  | 'storage'
  | 'gym'
  | 'theater'
  | 'playroom'
  | 'mudroom'
  | 'sunroom'
  | 'basement'
  | 'attic'
  | 'other';

/** Informações sobre tipo de cômodo */
export interface RoomTypeInfo {
  readonly type: RoomType;
  readonly displayName: string;
  readonly minWidth: number;      // metros
  readonly minDepth: number;      // metros
  readonly minArea: number;       // m²
  readonly idealWidth: number;
  readonly idealDepth: number;
  readonly ceilingHeight: number; // metros
  readonly naturalLight: 'required' | 'preferred' | 'optional';
  readonly ventilation: 'required' | 'preferred' | 'optional';
}

/** Cômodo - espaço delimitado por paredes */
export interface Room extends BaseEntity {
  readonly type: 'room';
  readonly roomType: RoomType;
  readonly name: string;
  /** Vértices do polígono em ordem CCW */
  readonly points: readonly Vec2[];
  /** IDs das paredes que delimitam este cômodo (em ordem) */
  readonly wallIds: readonly EntityId[];
  /** Área calculada em m² */
  readonly area: number;
  /** Perímetro em metros */
  readonly perimeter: number;
  /** Piso - material e cor */
  readonly floorMaterial: string | null;
  /** Teto - material e cor */
  readonly ceilingMaterial: string | null;
  /** Altura do pé direito */
  readonly ceilingHeight: number;
  /** IDs de móveis neste cômodo */
  readonly furnitureIds: readonly EntityId[];
  /** Metadados adicionais */
  readonly metadata: {
    readonly floorLevel: number;    // andar (0 = térreo)
    readonly isExterior: boolean;
    readonly notes: string | null;
  };
}

/** Zona/área funcional (grupo de cômodos) */
export interface RoomZone extends BaseEntity {
  readonly type: 'zone';
  readonly name: string;
  readonly color: string;
  readonly roomIds: readonly EntityId[];
}

/** Informações de detecção de cômodo */
export interface RoomDetectionResult {
  readonly rooms: readonly Room[];
  readonly confidence: number;    // 0-1
  readonly warnings: readonly string[];
}

/** Operação em cômodo */
export type RoomOperation =
  | { readonly kind: 'create'; readonly room: Room }
  | { readonly kind: 'update'; readonly roomId: EntityId; readonly previous: Partial<Room>; readonly next: Partial<Room> }
  | { readonly kind: 'delete'; readonly room: Room }
  | { readonly kind: 'move'; readonly roomId: EntityId; readonly delta: Vec2 }
  | { readonly kind: 'rotate'; readonly roomId: EntityId; readonly center: Vec2; readonly angle: number };

/** Regras de circulação entre cômodos */
export interface CirculationRule {
  readonly roomType1: RoomType;
  readonly roomType2: RoomType;
  readonly required: boolean;
  readonly minDoorWidth: number;
}

/** Restrição de adjacência */
export interface AdjacencyConstraint {
  readonly roomType: RoomType;
  readonly preferredAdjacent: readonly RoomType[];
  readonly avoidAdjacent: readonly RoomType[];
}
