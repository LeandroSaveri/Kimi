/**
 * AssetRegistry — Registro central de assets (modelos 3D, materiais, texturas)
 * Catálogo completo de objetos disponíveis para o editor
 */

export interface AssetMetadata {
  id: string;
  name: string;
  category: AssetCategory;
  tags: string[];
  thumbnailUrl?: string;
  modelUrl?: string;
  dimensions?: { width: number; height: number; depth: number };
  metadata?: Record<string, unknown>;
}

export type AssetCategory = 
  | 'furniture' 
  | 'appliance' 
  | 'fixture' 
  | 'material' 
  | 'texture' 
  | 'door' 
  | 'window' 
  | 'decoration'
  | 'structural';

class AssetRegistry {
  private assets: Map<string, AssetMetadata> = new Map();
  private listeners: Set<(assets: AssetMetadata[]) => void> = new Set();

  register(asset: AssetMetadata): void {
    this.assets.set(asset.id, asset);
    this.notifyListeners();
  }

  unregister(id: string): void {
    this.assets.delete(id);
    this.notifyListeners();
  }

  get(id: string): AssetMetadata | undefined {
    return this.assets.get(id);
  }

  getByCategory(category: AssetCategory): AssetMetadata[] {
    return Array.from(this.assets.values()).filter(a => a.category === category);
  }

  getAll(): AssetMetadata[] {
    return Array.from(this.assets.values());
  }

  search(query: string): AssetMetadata[] {
    const q = query.toLowerCase();
    return this.getAll().filter(a => 
      a.name.toLowerCase().includes(q) || 
      a.tags.some(t => t.toLowerCase().includes(q))
    );
  }

  onChange(listener: (assets: AssetMetadata[]) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners(): void {
    const assets = this.getAll();
    this.listeners.forEach(l => l(assets));
  }
}

export const assetRegistry = new AssetRegistry();
