/**
 * AssetCategoryManager — Gerenciamento de categorias de assets
 * Organiza assets por categoria para o catálogo de móveis e materiais
 */

export interface CategoryInfo {
  id: string;
  name: string;
  icon: string;
  count: number;
  subcategories?: string[];
}

class AssetCategoryManager {
  private categories: Map<string, CategoryInfo> = new Map();
  private listeners: Set<(categories: CategoryInfo[]) => void> = new Set();

  getCategories(): CategoryInfo[] {
    return Array.from(this.categories.values());
  }

  getCategory(id: string): CategoryInfo | undefined {
    return this.categories.get(id);
  }

  addCategory(category: CategoryInfo): void {
    this.categories.set(category.id, category);
    this.notifyListeners();
  }

  removeCategory(id: string): void {
    this.categories.delete(id);
    this.notifyListeners();
  }

  onChange(listener: (categories: CategoryInfo[]) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners(): void {
    const cats = this.getCategories();
    this.listeners.forEach(l => l(cats));
  }
}

export const assetCategoryManager = new AssetCategoryManager();
