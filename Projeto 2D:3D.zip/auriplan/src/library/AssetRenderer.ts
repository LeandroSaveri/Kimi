/**
 * AssetRenderer — Renderização de assets 3D na cena
 * Gerencia o ciclo de vida dos meshes 3D dos assets no editor
 */

import type { Group } from 'three';
import type { AssetMetadata } from './AssetRegistry';

export interface RenderedAsset {
  id: string;
  assetId: string;
  mesh: Group;
  position: [number, number, number];
  rotation: [number, number, number];
  scale: [number, number, number];
}

class AssetRenderer {
  private renderedAssets: Map<string, RenderedAsset> = new Map();

  async renderAsset(asset: AssetMetadata, position: [number, number, number]): Promise<RenderedAsset | null> {
    // Placeholder — carregamento real seria implementado aqui
    const group = new (await import('three')).Group();
    
    const rendered: RenderedAsset = {
      id: crypto.randomUUID(),
      assetId: asset.id,
      mesh: group,
      position,
      rotation: [0, 0, 0],
      scale: [1, 1, 1],
    };

    this.renderedAssets.set(rendered.id, rendered);
    return rendered;
  }

  removeRendered(id: string): void {
    const rendered = this.renderedAssets.get(id);
    if (rendered) {
      // Cleanup Three.js resources
      rendered.mesh.traverse(child => {
        if ((child as { geometry?: unknown }).geometry) {
          // dispose geometry
        }
      });
      this.renderedAssets.delete(id);
    }
  }

  getRendered(id: string): RenderedAsset | undefined {
    return this.renderedAssets.get(id);
  }

  getAllRendered(): RenderedAsset[] {
    return Array.from(this.renderedAssets.values());
  }
}

export const assetRenderer = new AssetRenderer();
