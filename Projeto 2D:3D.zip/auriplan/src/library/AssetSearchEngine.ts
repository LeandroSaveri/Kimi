/**
 * AssetSearchEngine — Motor de busca de assets
 * Permite encontrar assets por texto, categoria e filtros
 */

import { assetRegistry, type AssetMetadata } from './AssetRegistry';

export interface SearchFilters {
  category?: string;
  tags?: string[];
  dimensions?: {
    maxWidth?: number;
    maxHeight?: number;
    maxDepth?: number;
  };
}

export interface SearchResult {
  asset: AssetMetadata;
  score: number;
}

class AssetSearchEngine {
  search(query: string, filters?: SearchFilters): SearchResult[] {
    let results = assetRegistry.search(query);

    if (filters?.category) {
      results = results.filter(a => a.category === filters.category);
    }

    if (filters?.tags) {
      results = results.filter(a => 
        filters.tags!.every(t => a.tags.includes(t))
      );
    }

    return results.map(asset => ({
      asset,
      score: this.calculateScore(asset, query),
    })).sort((a, b) => b.score - a.score);
  }

  private calculateScore(asset: AssetMetadata, query: string): number {
    const q = query.toLowerCase();
    let score = 0;
    
    if (asset.name.toLowerCase().includes(q)) score += 10;
    if (asset.tags.some(t => t.toLowerCase().includes(q))) score += 5;
    
    return score;
  }
}

export const assetSearchEngine = new AssetSearchEngine();
