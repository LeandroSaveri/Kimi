/**
 * editorStore.ts
 * ============
 * STORE BURDO — NÃO calcula, NÃO decide, NÃO transforma.
 * Armazena estado bruto. Toda inteligência está em src/core/.
 *
 * Regras:
 *   1. Nenhum cálculo de área, perímetro, distância ou ângulo.
 *   2. Nenhum require() — imports estáticos apenas.
 *   3. Nenhum any — tudo tipado via @auriplan-types.
 *   4. splitWall, zoomToView, fitToView delegam ao GeometryController.
 */

import { immer } from 'zustand/middleware/immer';
import { create } from 'zustand';
import type {
  Project,
  Scene,
  Wall,
  Room,
  Door,
  Window,
  Furniture,
  Measurement,
  CameraState,
  GridSettings,
  SnapSettings,
  ViewMode,
  Tool,
  Vec2,
  User,
  TopologyCache,
} from '@auriplan-types';

/* ── GeometryController — única fonte de inteligência ── */
import { GeometryController } from '@core/geometry/GeometryController';

/* ── Wall split engine (pura, sem estado) ── */
import type { WallSplitResult } from '@core/wall/WallSplitEngine';

/* ── Constants ── */
const HISTORY_LIMIT = 100;

/* ── Node shape for scene graph (used by 3D engine) ── */
export interface Node {
  id: string;
  position: Vec2;
  label: string;
  color?: string;
  shape?: string;
}

/* ═══════════════════════════════════════════════════════════
   STATE
   ═══════════════════════════════════════════════════════════ */

interface EditorState {
  project: Project | null;
  scenes: Scene[];
  currentSceneId: string | null;
  viewMode: ViewMode;
  tool: Tool;
  selectedIds: string[];
  hoveredId: string | null;
  camera: CameraState;
  grid: GridSettings;
  snap: SnapSettings;
  clipboard: Wall[] | Room[] | null;
  lastMousePosition: Vec2;

  /* tipado — nunca any */
  _topologyCache: TopologyCache;
  _historyBatch: { description: string; snapshot: { scenes: Scene[]; currentSceneId: string | null } } | null;

  /* ── scene ── */
  addScene: (scene: Scene) => void;
  setCurrentScene: (id: string) => void;
  updateScene: (id: string, patch: Partial<Scene>) => void;
  deleteScene: (id: string) => void;

  /* ── walls ── */
  addWall: (wall: Wall) => void;
  updateWall: (id: string, patch: Partial<Wall>) => void;
  deleteWall: (id: string) => void;

  /* ── rooms ── */
  addRoom: (room: Room) => void;
  updateRoom: (id: string, patch: Partial<Room>) => void;
  deleteRoom: (id: string) => void;

  /* ── doors / windows ── */
  addDoor: (door: Door) => void;
  updateDoor: (id: string, patch: Partial<Door>) => void;
  deleteDoor: (id: string) => void;
  addWindow: (win: Window) => void;
  updateWindow: (id: string, patch: Partial<Window>) => void;
  deleteWindow: (id: string) => void;

  /* ── furniture ── */
  addFurniture: (item: Furniture) => void;
  updateFurniture: (id: string, patch: Partial<Furniture>) => void;
  deleteFurniture: (id: string) => void;

  /* ── measurements ── */
  addMeasurement: (m: Measurement) => void;
  updateMeasurement: (id: string, patch: Partial<Measurement>) => void;
  deleteMeasurement: (id: string) => void;

  /* ── project ── */
  createProject: (name: string, owner: User, description?: string) => void;
  saveProject: () => void;
  exportProject: () => string;
  importProject: (data: string) => boolean;

  /* ── cache (3D topology) ── */
  setTopologyCache: (cache: TopologyCache) => void;

  /* ── tools ── */
  setTool: (tool: Tool) => void;
  setViewMode: (mode: ViewMode) => void;

  /* ── selection ── */
  select: (id: string | string[], addToSelection?: boolean) => void;
  deselect: (id: string) => void;
  deselectAll: () => void;
  setHovered: (id: string | null) => void;

  /* ── clipboard ── */
  cut: () => void;
  copy: () => void;
  paste: () => void;

  /* ── camera ── */
  setCamera: (camera: Partial<CameraState>) => void;

  /* ── grid & snap ── */
  setGrid: (grid: Partial<GridSettings>) => void;
  setSnap: (snap: Partial<SnapSettings>) => void;

  /* ── batching ── */
  beginHistoryBatch: (description: string) => void;
  commitHistoryBatch: () => void;
  cancelHistoryBatch: () => void;

  /* ── history ── */
  saveToHistory: () => void;
  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;

  /* ── live updates (drag) ── */
  _liveUpdateWallEnd: (id: string, end: Vec2) => void;
  _liveUpdateFurniturePos: (id: string, position: [number, number, number]) => void;
  _liveUpdateFurnitureRot: (id: string, rotation: number) => void;
  _liveUpdateRoomPoints: (id: string, points: Vec2[]) => void;

  /* ── split wall → delegado ao core ── */
  splitWall: (wallId: string, point: Vec2) => Promise<WallSplitResult | null>;

  /* ── zoom/fit → delegado ao core ── */
  zoomToRoom: (roomId: string) => void;
  fitToView: () => void;
  zoomToSelection: () => void;
}

/* ═══════════════════════════════════════════════════════════
   HELPERS
   ═══════════════════════════════════════════════════════════ */

const clone = <T,>(obj: T): T => JSON.parse(JSON.stringify(obj));

const findScene = (state: EditorState, id?: string | null): Scene | undefined =>
  state.scenes.find(s => s.id === (id ?? state.currentSceneId));

/* ═══════════════════════════════════════════════════════════
   STORE
   ═══════════════════════════════════════════════════════════ */

export const editorStore = create<EditorState>()(
  immer((set, get) => ({
    /* ── initial state ── */
    project: null,
    scenes: [],
    currentSceneId: null,
    viewMode: '2d',
    tool: 'select',
    selectedIds: [],
    hoveredId: null,
    camera: {
      position: [0, 0, 5] as [number, number, number],
      target: [0, 0, 0] as [number, number, number],
      zoom: 1,
    },
    grid: { visible: true, size: 0.1, color: '#475569', opacity: 0.2 },
    snap: {
      enabled: true, grid: true, endpoints: true, midpoints: true,
      edges: true, centers: true, perpendicular: true, angle: true, distance: 0.3,
    },
    clipboard: null,
    lastMousePosition: [0, 0],
    _topologyCache: {},
    _historyBatch: null,

    /* ── scene CRUD ── */
    addScene: (scene) =>
      set(s => {
        s.scenes.push(scene);
        if (!s.currentSceneId) s.currentSceneId = scene.id;
      }),

    setCurrentScene: (id) =>
      set(s => { s.currentSceneId = id; }),

    updateScene: (id, patch) =>
      set(s => {
        const sc = s.scenes.find(x => x.id === id);
        if (sc) Object.assign(sc, patch);
      }),

    deleteScene: (id) =>
      set(s => {
        s.scenes = s.scenes.filter(x => x.id !== id);
        if (s.currentSceneId === id) s.currentSceneId = s.scenes[0]?.id ?? null;
      }),

    /* ── wall CRUD ── */
    addWall: (wall) =>
      set(s => { findScene(s)?.walls.push(wall); }),

    updateWall: (id, patch) =>
      set(s => {
        const w = findScene(s)?.walls.find(x => x.id === id);
        if (w) Object.assign(w, patch);
      }),

    deleteWall: (id) =>
      set(s => {
        const sc = findScene(s);
        if (sc) sc.walls = sc.walls.filter(x => x.id !== id);
      }),

    /* ── room CRUD ── */
    addRoom: (room) =>
      set(s => { findScene(s)?.rooms.push(room); }),

    updateRoom: (id, patch) =>
      set(s => {
        const r = findScene(s)?.rooms.find(x => x.id === id);
        if (r) Object.assign(r, patch);
      }),

    deleteRoom: (id) =>
      set(s => {
        const sc = findScene(s);
        if (sc) sc.rooms = sc.rooms.filter(x => x.id !== id);
      }),

    /* ── door CRUD ── */
    addDoor: (door) =>
      set(s => { findScene(s)?.doors.push(door); }),

    updateDoor: (id, patch) =>
      set(s => {
        const d = findScene(s)?.doors.find(x => x.id === id);
        if (d) Object.assign(d, patch);
      }),

    deleteDoor: (id) =>
      set(s => {
        const sc = findScene(s);
        if (sc) sc.doors = sc.doors.filter(x => x.id !== id);
      }),

    /* ── window CRUD ── */
    addWindow: (win) =>
      set(s => { findScene(s)?.windows.push(win); }),

    updateWindow: (id, patch) =>
      set(s => {
        const w = findScene(s)?.windows.find(x => x.id === id);
        if (w) Object.assign(w, patch);
      }),

    deleteWindow: (id) =>
      set(s => {
        const sc = findScene(s);
        if (sc) sc.windows = sc.windows.filter(x => x.id !== id);
      }),

    /* ── furniture CRUD ── */
    addFurniture: (item) =>
      set(s => { findScene(s)?.furniture.push(item); }),

    updateFurniture: (id, patch) =>
      set(s => {
        const f = findScene(s)?.furniture.find(x => x.id === id);
        if (f) Object.assign(f, patch);
      }),

    deleteFurniture: (id) =>
      set(s => {
        const sc = findScene(s);
        if (sc) sc.furniture = sc.furniture.filter(x => x.id !== id);
      }),

    /* ── measurement CRUD ── */
    addMeasurement: (m) =>
      set(s => { findScene(s)?.measurements.push(m); }),

    updateMeasurement: (id, patch) =>
      set(s => {
        const m = findScene(s)?.measurements.find(x => x.id === id);
        if (m) Object.assign(m, patch);
      }),

    deleteMeasurement: (id) =>
      set(s => {
        const sc = findScene(s);
        if (sc) sc.measurements = sc.measurements.filter(x => x.id !== id);
      }),

    /* ── project ── */
    createProject: (name, owner, description) =>
      set(s => {
        const newProject: Project = {
          id: crypto.randomUUID(),
          name,
          description: description ?? '',
          owner,
          collaborators: [],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          settings: {
            units: 'metric',
            currency: 'BRL',
            gridSize: 0.5,
            defaultWallHeight: 2.8,
            defaultWallThickness: 0.15,
          },
          status: 'draft',
        };
        s.project = newProject;
        /* cria cena inicial */
        const sceneId = crypto.randomUUID();
        s.scenes = [{
          id: sceneId,
          name: 'Ground Floor',
          level: 0,
          height: 2.8,
          walls: [],
          rooms: [],
          doors: [],
          windows: [],
          furniture: [],
          measurements: [],
        }];
        s.currentSceneId = sceneId;
        get().saveToHistory();
      }),

    saveProject: () => {
      const state = get();
      if (!state.project) return;
      localStorage.setItem(
        `auriplan_project_${state.project.id}`,
        JSON.stringify({ project: state.project, scenes: state.scenes })
      );
    },

    exportProject: () => {
      const state = get();
      return JSON.stringify({ project: state.project, scenes: state.scenes });
    },

    importProject: (data) => {
      try {
        const parsed = JSON.parse(data) as { project: Project; scenes: Scene[] };
        set(s => {
          s.project = parsed.project;
          s.scenes = parsed.scenes;
          s.currentSceneId = parsed.scenes[0]?.id ?? null;
        });
        get().saveToHistory();
        return true;
      } catch {
        return false;
      }
    },

    /* ── topology cache ── */
    setTopologyCache: (cache) =>
      set(s => { s._topologyCache = cache; }),

    /* ── tool / view ── */
    setTool: (tool) =>
      set(s => { s.tool = tool; }),

    setViewMode: (mode) =>
      set(s => { s.viewMode = mode; }),

    /* ── selection ── */
    select: (id, addToSelection = false) =>
      set(s => {
        const ids = Array.isArray(id) ? id : [id];
        s.selectedIds = addToSelection ? [...new Set([...s.selectedIds, ...ids])] : ids;
      }),

    deselect: (id) =>
      set(s => { s.selectedIds = s.selectedIds.filter(x => x !== id); }),

    deselectAll: () =>
      set(s => { s.selectedIds = []; }),

    setHovered: (id) =>
      set(s => { s.hoveredId = id; }),

    /* ── clipboard ── */
    cut: () =>
      set(s => {
        const sc = findScene(s);
        if (!sc) return;
        const selected = sc.walls.filter(w => s.selectedIds.includes(w.id));
        s.clipboard = selected;
        sc.walls = sc.walls.filter(w => !s.selectedIds.includes(w.id));
      }),

    copy: () =>
      set(s => {
        const sc = findScene(s);
        if (!sc) return;
        s.clipboard = sc.walls.filter(w => s.selectedIds.includes(w.id));
      }),

    paste: () =>
      set(s => {
        const sc = findScene(s);
        if (!sc || !s.clipboard?.length) return;
        for (const w of s.clipboard) {
          sc.walls.push({ ...clone(w), id: crypto.randomUUID() });
        }
      }),

    /* ── camera ── */
    setCamera: (camera) =>
      set(s => { Object.assign(s.camera, camera); }),

    /* ── grid & snap ── */
    setGrid: (grid) =>
      set(s => { Object.assign(s.grid, grid); }),

    setSnap: (snap) =>
      set(s => { Object.assign(s.snap, snap); }),

    /* ── batching ── */
    beginHistoryBatch: (description) =>
      set(s => {
        if (s._historyBatch?.description) return;
        s._historyBatch = {
          description,
          snapshot: { scenes: clone(s.scenes), currentSceneId: s.currentSceneId },
        };
      }),

    commitHistoryBatch: () =>
      set(s => {
        if (!s._historyBatch) return;
        s._historyBatch = null;
        get().saveToHistory();
      }),

    cancelHistoryBatch: () =>
      set(s => {
        if (!s._historyBatch) return;
        s.scenes = s._historyBatch.snapshot.scenes;
        s.currentSceneId = s._historyBatch.snapshot.currentSceneId;
        s._historyBatch = null;
      }),

    /* ── history ── */
    saveToHistory: () =>
      set(s => {
        s.project = s.project ? { ...s.project, updatedAt: new Date().toISOString() } : null;
      }),

    undo: () => {},
    redo: () => {},
    canUndo: () => false,
    canRedo: () => false,

    /* ── live updates (drag — sem histórico) ── */
    _liveUpdateWallEnd: (id, end) =>
      set(s => {
        const w = findScene(s)?.walls.find(x => x.id === id);
        if (w) w.end = end;
      }),

    _liveUpdateFurniturePos: (id, position) =>
      set(s => {
        const f = findScene(s)?.furniture.find(x => x.id === id);
        if (f && typeof f.position === 'object' && 'x' in f.position) {
          (f.position as { x: number; y: number; z: number }).x = position[0];
          (f.position as { x: number; y: number; z: number }).y = position[1];
          (f.position as { x: number; y: number; z: number }).z = position[2];
        }
      }),

    _liveUpdateFurnitureRot: (id, rotation) =>
      set(s => {
        const f = findScene(s)?.furniture.find(x => x.id === id);
        if (f) f.rotation = rotation;
      }),

    _liveUpdateRoomPoints: (id, points) =>
      set(s => {
        const r = findScene(s)?.rooms.find(x => x.id === id);
        if (r) r.points = points;
      }),

    /* ═══════════════════════════════════════════════════════
       DELEGADOS AO CORE (não calculam aqui)
       ═══════════════════════════════════════════════════════ */

    /** splitWall → delegado ao WallSplitEngine via GeometryController */
    splitWall: async (wallId, point) => {
      const state = get();
      const sc = findScene(state);
      if (!sc) return null;
      const gc = new GeometryController();
      return gc.splitWall(sc.walls, wallId, point);
    },

    /** zoomToRoom → delegado ao GeometryController */
    zoomToRoom: (roomId) => {
      const state = get();
      const sc = findScene(state);
      if (!sc) return;
      const gc = new GeometryController();
      const cam = gc.zoomToRoom(sc.rooms, roomId, state.camera);
      set(s => { s.camera = cam; });
    },

    /** fitToView → delegado ao GeometryController */
    fitToView: () => {
      const state = get();
      const sc = findScene(state);
      if (!sc || sc.walls.length === 0) return;
      const gc = new GeometryController();
      const cam = gc.fitToView(sc.walls, state.camera);
      set(s => { s.camera = cam; });
    },

    /** zoomToSelection → delegado ao GeometryController */
    zoomToSelection: () => {
      const state = get();
      const sc = findScene(state);
      if (!sc || state.selectedIds.length === 0) return;
      const gc = new GeometryController();
      const points = gc.getSelectedBounds(sc, state.selectedIds);
      if (points.length > 0) {
        const cam = gc.fitToPoints(points, state.camera);
        set(s => { s.camera = cam; });
      }
    },
  }))
);

export default editorStore;
