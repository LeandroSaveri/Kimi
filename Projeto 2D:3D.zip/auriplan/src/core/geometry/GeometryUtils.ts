/**
 * GeometryUtils.ts
 * Funções puras de cálculo geométrico. Nenhuma dependência de estado.
 * Usado pelo GeometryController e por live updates.
 */

import type { Vec2 } from '@auriplan-types';

/** Calcula área de polígono pela fórmula do shoelace */
export function calculatePolygonArea(points: Vec2[]): number {
  if (points.length < 3) return 0;
  let area = 0;
  for (let i = 0; i < points.length; i++) {
    const j = (i + 1) % points.length;
    area += points[i][0] * points[j][1] - points[j][0] * points[i][1];
  }
  return Math.abs(area) / 2;
}

/** Calcula perímetro de um polígono */
export function calculatePolygonPerimeter(points: Vec2[]): number {
  if (points.length < 2) return 0;
  let perim = 0;
  for (let i = 0; i < points.length; i++) {
    const j = (i + 1) % points.length;
    perim += Math.hypot(points[j][0] - points[i][0], points[j][1] - points[i][1]);
  }
  return perim;
}

/** Calcula bounding box de um conjunto de pontos */
export function calculateBounds(points: Vec2[]): {
  minX: number; minY: number; maxX: number; maxY: number;
  centerX: number; centerY: number; width: number; height: number;
} {
  if (points.length === 0) {
    return { minX: 0, minY: 0, maxX: 0, maxY: 0, centerX: 0, centerY: 0, width: 0, height: 0 };
  }

  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of points) {
    minX = Math.min(minX, p[0]);
    minY = Math.min(minY, p[1]);
    maxX = Math.max(maxX, p[0]);
    maxY = Math.max(maxY, p[1]);
  }

  return {
    minX, minY, maxX, maxY,
    centerX: (minX + maxX) / 2,
    centerY: (minY + maxY) / 2,
    width: maxX - minX,
    height: maxY - minY,
  };
}

/** Calcula zoom para enquadrar bounds em uma viewport */
export function calculateZoomForBounds(
  boundsWidth: number,
  boundsHeight: number,
  viewportWidth: number,
  viewportHeight: number,
  padding: number = 0.1
): number {
  if (boundsWidth === 0 || boundsHeight === 0) return 1;
  const scaleX = viewportWidth / (boundsWidth * (1 + padding));
  const scaleY = viewportHeight / (boundsHeight * (1 + padding));
  return Math.min(scaleX, scaleY, 10);
}
