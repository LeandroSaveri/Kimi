/**
 * polygonHelpers — Funções puras de cálculo de polígonos
 * Centralizado no core — nenhum componente deve calcular área diretamente
 */

import type { Vec2, Point2D } from '@auriplan-types';

/** Calcula área de um polígono pela fórmula do shoelace */
export function calculatePolygonArea(points: Array<{ x: number; y: number }> | Vec2[]): number {
  if (points.length < 3) return 0;
  let area = 0;
  for (let i = 0; i < points.length; i++) {
    const j = (i + 1) % points.length;
    const x1 = Array.isArray(points[i]) ? (points[i] as Vec2)[0] : (points[i] as Point2D).x;
    const y1 = Array.isArray(points[i]) ? (points[i] as Vec2)[1] : (points[i] as Point2D).y;
    const x2 = Array.isArray(points[j]) ? (points[j] as Vec2)[0] : (points[j] as Point2D).x;
    const y2 = Array.isArray(points[j]) ? (points[j] as Vec2)[1] : (points[j] as Point2D).y;
    area += x1 * y2 - x2 * y1;
  }
  return Math.abs(area) / 2;
}

/** Calcula centróide de um polígono */
export function calculateCentroid(points: Array<{ x: number; y: number }> | Vec2[]): { x: number; y: number } {
  if (points.length === 0) return { x: 0, y: 0 };
  let cx = 0, cy = 0;
  for (const p of points) {
    cx += Array.isArray(p) ? p[0] : p.x;
    cy += Array.isArray(p) ? p[1] : p.y;
  }
  return { x: cx / points.length, y: cy / points.length };
}

/** Verifica se um ponto está dentro de um polígono (ray casting) */
export function pointInPolygon(
  point: { x: number; y: number } | Vec2,
  polygon: Array<{ x: number; y: number }> | Vec2[]
): boolean {
  const px = Array.isArray(point) ? point[0] : point.x;
  const py = Array.isArray(point) ? point[1] : point.y;

  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const xi = Array.isArray(polygon[i]) ? (polygon[i] as Vec2)[0] : (polygon[i] as { x: number }).x;
    const yi = Array.isArray(polygon[i]) ? (polygon[i] as Vec2)[1] : (polygon[i] as { y: number }).y;
    const xj = Array.isArray(polygon[j]) ? (polygon[j] as Vec2)[0] : (polygon[j] as { x: number }).x;
    const yj = Array.isArray(polygon[j]) ? (polygon[j] as Vec2)[1] : (polygon[j] as { y: number }).y;

    const intersect = ((yi > py) !== (yj > py)) && (px < (xj - xi) * (py - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

/** Verifica se um polígono é válido (não-degenerado) */
export function isValidPolygon(points: Array<{ x: number; y: number }> | Vec2[]): boolean {
  return points.length >= 3 && calculatePolygonArea(points) > 0;
}

/** Calcula bounding box de um polígono */
export function polygonBounds(points: Array<{ x: number; y: number }> | Vec2[]): {
  minX: number; minY: number; maxX: number; maxY: number; width: number; height: number;
} {
  if (points.length === 0) return { minX: 0, minY: 0, maxX: 0, maxY: 0, width: 0, height: 0 };

  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of points) {
    const x = Array.isArray(p) ? p[0] : p.x;
    const y = Array.isArray(p) ? p[1] : p.y;
    minX = Math.min(minX, x);
    minY = Math.min(minY, y);
    maxX = Math.max(maxX, x);
    maxY = Math.max(maxY, y);
  }
  return { minX, minY, maxX, maxY, width: maxX - minX, height: maxY - minY };
}
