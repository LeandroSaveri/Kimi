/**
 * WallSplitEngine.ts
 * Lógica pura de divisão de paredes. Nenhuma dependência do store.
 */

import type { Vec2, Wall } from '@auriplan-types';
import { v4 as uuidv4 } from 'uuid';

export interface WallSegment {
  wallId: string;
  start: Vec2;
  end: Vec2;
  tStart: number;
  tEnd: number;
}

export interface WallSplitResult {
  segments: WallSegment[];
  updatedWalls: Wall[];
  removedWallIds: string[];
}

/**
 * Calcula o parâmetro t de um ponto sobre uma parede (0=start, 1=end)
 */
function getParameterOnWall(wall: Wall, point: Vec2): number {
  const dx = wall.end[0] - wall.start[0];
  const dy = wall.end[1] - wall.start[1];
  const lenSq = dx * dx + dy * dy;
  if (lenSq === 0) return 0;

  const t = ((point[0] - wall.start[0]) * dx + (point[1] - wall.start[1]) * dy) / lenSq;
  return Math.max(0, Math.min(1, t));
}

/**
 * Gera um ponto na parede no parâmetro t
 */
function getPointAt(wall: Wall, t: number): Vec2 {
  return [
    wall.start[0] + t * (wall.end[0] - wall.start[0]),
    wall.start[1] + t * (wall.end[1] - wall.start[1]),
  ];
}

/**
 * Comprimento de um segmento
 */
function segmentLength(a: Vec2, b: Vec2): number {
  return Math.hypot(b[0] - a[0], b[1] - a[1]);
}

/**
 * Divide uma parede em um ponto. Retorna os segmentos resultantes.
 */
export function splitWallAtPoint(
  walls: Wall[],
  wallId: string,
  point: Vec2
): WallSplitResult {
  const wall = walls.find(w => w.id === wallId);
  if (!wall) return { segments: [], updatedWalls: [...walls], removedWallIds: [] };

  const t = getParameterOnWall(wall, point);

  // Se o ponto está muito próximo do início ou fim, não divide
  if (t < 1e-6 || t > 1 - 1e-6) {
    return { segments: [], updatedWalls: [...walls], removedWallIds: [] };
  }

  const splitPoint = getPointAt(wall, t);
  const newWallId1 = uuidv4();
  const newWallId2 = uuidv4();

  const wall1: Wall = {
    ...wall,
    id: newWallId1,
    start: [...wall.start] as Vec2,
    end: [...splitPoint] as Vec2,
  };

  const wall2: Wall = {
    ...wall,
    id: newWallId2,
    start: [...splitPoint] as Vec2,
    end: [...wall.end] as Vec2,
  };

  const segments: WallSegment[] = [
    { wallId: newWallId1, start: wall1.start, end: wall1.end, tStart: 0, tEnd: t },
    { wallId: newWallId2, start: wall2.start, end: wall2.end, tStart: t, tEnd: 1 },
  ];

  const updatedWalls = walls.filter(w => w.id !== wallId).concat(wall1, wall2);

  return {
    segments,
    updatedWalls,
    removedWallIds: [wallId],
  };
}

/**
 * Reatribui aberturas (portas/janelas) para os segmentos de parede resultantes.
 * Retorna as aberturas atualizadas com seus novos wallIds e positions.
 */
export function reassignOpenings<T extends { wallId: string; position: number }>(
  openings: T[],
  oldWallId: string,
  segments: WallSegment[]
): T[] {
  if (segments.length === 0) return openings;

  // Comprimento total da parede original
  const totalLength = segments.reduce(
    (sum, seg) => sum + segmentLength(seg.start, seg.end),
    0
  );

  return openings.map(op => {
    if (op.wallId !== oldWallId) return op;

    // Converte position absoluta para t global
    const globalT = totalLength > 0 ? op.position / totalLength : 0;

    // Encontra o segmento correspondente
    let accumLength = 0;
    for (const seg of segments) {
      const segLen = segmentLength(seg.start, seg.end);
      const segStartT = accumLength / totalLength;
      const segEndT = (accumLength + segLen) / totalLength;

      if (globalT >= segStartT - 1e-6 && globalT <= segEndT + 1e-6) {
        // Converte t global para t local no segmento
        const localT = segLen > 0
          ? (globalT - segStartT) / ((segEndT - segStartT) || 1)
          : 0;
        return {
          ...op,
          wallId: seg.wallId,
          position: localT * segLen,
        };
      }
      accumLength += segLen;
    }

    // Fallback: atribui ao primeiro segmento
    return { ...op, wallId: segments[0].wallId };
  });
}
