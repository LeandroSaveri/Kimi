
// ============================================
// WallGraph.ts – implementação concreta de IGraphTopology
// Fase 4: Ajuste de cantos com validação de comprimento mínimo
// ============================================

import type { Vec2, Wall } from '@auriplan-types';
import type { IGraphTopology } from '@core/topology/IGraphTopology';
import {
  GEOM_TOL,
  EPS,
  ANGLE_TOL,
  OPPOSITE_ANGLE_TOL,
  MAX_MITER_FACTOR,
  MIN_WALL_LENGTH,
} from '@core/geometry/geometryConstants';
import { vec2, geometry } from '@core/math/vector';

// ======================== TIPOS DA ENGINE ========================
export interface WallIncident {
  wallIndex: number;
  side: 'start' | 'end';
  dir: Vec2;
  angle: number;
  wall: Wall;
  leftPoint: Vec2;
  rightPoint: Vec2;
  leftLine: [Vec2, Vec2];
  rightLine: [Vec2, Vec2];
}

export interface WallGraphNode {
  position: Vec2;
  incidents: WallIncident[];
}

export interface WallGraph {
  nodes: WallGraphNode[];
  junctions: Map<number, JunctionInfo>;
}

export type JunctionType = 'L' | 'T' | 'X' | 'none';

export interface JunctionInfo {
  nodeIndex: number;
  type: JunctionType;
  incidents: WallIncident[];
}

export function createEmptyWallGraph(): WallGraph {
  return { nodes: [], junctions: new Map() };
}

export function createEmptyWallGraphTopology(): IGraphTopology {
  return new WallGraphTopology([]);
}

const computeWallOffsets = (wall: Wall) => {
  const dx = wall.end[0] - wall.start[0];
  const dy = wall.end[1] - wall.start[1];
  const length = Math.hypot(dx, dy);
  if (length < EPS) return null;
  const nx = -dy / length;
  const ny = dx / length;
  const half = wall.thickness / 2;
  return {
    p1: [wall.start[0] + nx * half, wall.start[1] + ny * half] as Vec2,
    p2: [wall.start[0] - nx * half, wall.start[1] - ny * half] as Vec2,
    p3: [wall.end[0] - nx * half, wall.end[1] - ny * half] as Vec2,
    p4: [wall.end[0] + nx * half, wall.end[1] + ny * half] as Vec2,
  };
};

const areOppositeAngles = (a: number, b: number): boolean => {
  let diff = Math.abs(a - b);
  diff = Math.min(diff, 2 * Math.PI - diff);
  return Math.abs(diff - Math.PI) <= OPPOSITE_ANGLE_TOL;
};

export function buildGraph(walls: Wall[]): WallGraph {
  const n = walls.length;
  if (n === 0) return createEmptyWallGraph();

  const nodes: Vec2[] = [];
  const endpointToNodeIdx = new Map<string, number>();

  const findOrCreateNode = (p: Vec2): number => {
    for (let i = 0; i < nodes.length; i++) {
      if (vec2.distance(nodes[i], p) <= GEOM_TOL) return i;
    }
    const idx = nodes.length;
    nodes.push([p[0], p[1]]);
    return idx;
  };

  for (let i = 0; i < n; i++) {
    const w = walls[i];
    const startIdx = findOrCreateNode(w.start);
    const endIdx = findOrCreateNode(w.end);
    endpointToNodeIdx.set(`${i}-s`, startIdx);
    endpointToNodeIdx.set(`${i}-e`, endIdx);
  }

  const offsets = new Array(n);
  for (let i = 0; i < n; i++) {
    offsets[i] = computeWallOffsets(walls[i]);
  }

  const nodeToIncidents = new Map<number, WallIncident[]>();

  for (let i = 0; i < n; i++) {
    const w = walls[i];
    const off = offsets[i];
    if (!off) continue;

    const dirRaw = vec2.normalize(vec2.sub(w.end, w.start));
    if (dirRaw[0] === 0 && dirRaw[1] === 0) continue;

    const startNode = endpointToNodeIdx.get(`${i}-s`)!;
    const startDir: Vec2 = dirRaw;
    const startAngle = Math.atan2(startDir[1], startDir[0]);
    const startIncident: WallIncident = {
      wallIndex: i, side: 'start', dir: startDir, angle: startAngle, wall: w,
      leftPoint: off.p1, rightPoint: off.p2,
      leftLine: [off.p1, off.p4], rightLine: [off.p2, off.p3],
    };
    if (!nodeToIncidents.has(startNode)) nodeToIncidents.set(startNode, []);
    nodeToIncidents.get(startNode)!.push(startIncident);

    const endNode = endpointToNodeIdx.get(`${i}-e`)!;
    const endDir: Vec2 = [-dirRaw[0], -dirRaw[1]];
    const endAngle = Math.atan2(endDir[1], endDir[0]);
    const endIncident: WallIncident = {
      wallIndex: i, side: 'end', dir: endDir, angle: endAngle, wall: w,
      leftPoint: off.p4, rightPoint: off.p3,
      leftLine: [off.p4, off.p1], rightLine: [off.p3, off.p2],
    };
    if (!nodeToIncidents.has(endNode)) nodeToIncidents.set(endNode, []);
    nodeToIncidents.get(endNode)!.push(endIncident);
  }

  const graphNodes: WallGraphNode[] = nodes.map((pos, idx) => ({
    position: pos,
    incidents: nodeToIncidents.get(idx) || [],
  }));

  const junctionInfoMap = new Map<number, JunctionInfo>();

  for (const [nodeIdx, incidents] of nodeToIncidents) {
    const m = incidents.length;
    if (m < 2) continue;

    incidents.sort((a, b) => {
      const diff = a.angle - b.angle;
      if (Math.abs(diff) < ANGLE_TOL) {
        if (a.wallIndex !== b.wallIndex) return a.wallIndex - b.wallIndex;
        return a.side === 'start' ? -1 : 1;
      }
      return diff;
    });

    let type: JunctionType = 'none';

    if (m === 2) {
      type = 'L';
    } else if (m === 3) {
      const angles = incidents.map(i => i.angle);
      let legIdx = -1;
      for (let j = 0; j < m; j++) {
        let oppositeFound = false;
        for (let k = 0; k < m; k++) {
          if (j === k) continue;
          if (areOppositeAngles(angles[j], angles[k])) {
            oppositeFound = true;
            break;
          }
        }
        if (!oppositeFound) { legIdx = j; break; }
      }
      if (legIdx !== -1) type = 'T';
    } else if (m === 4) {
      const angles = incidents.map(i => i.angle);
      const pairs: number[][] = [];
      for (let i = 0; i < 4; i++) {
        for (let j = i + 1; j < 4; j++) {
          if (areOppositeAngles(angles[i], angles[j])) pairs.push([i, j]);
        }
      }
      if (pairs.length === 2 && pairs[0][0] !== pairs[1][0] && pairs[0][0] !== pairs[1][1] &&
          pairs[0][1] !== pairs[1][0] && pairs[0][1] !== pairs[1][1]) {
        type = 'X';
      }
    }

    junctionInfoMap.set(nodeIdx, { nodeIndex: nodeIdx, type, incidents: [...incidents] });
  }

  return { nodes: graphNodes, junctions: junctionInfoMap };
}

// ==================== FUNÇÃO AUXILIAR DE VALIDAÇÃO ====================
/**
 * Verifica se a aplicação de novos start/end manteria a parede com comprimento mínimo.
 */
function wouldBeValidLength(wall: Wall, newStart?: Vec2, newEnd?: Vec2): boolean {
  const start = newStart ?? wall.start;
  const end = newEnd ?? wall.end;
  return vec2.distance(start, end) >= MIN_WALL_LENGTH - EPS;
}

// ==================== FASE 4 CORRIGIDA ====================
export function computeCornerAdjustments(
  graph: WallGraph,
  walls: Wall[]
): Map<number, { start?: Vec2; end?: Vec2 }> {
  const adjustments = new Map<number, { start?: Vec2; end?: Vec2 }>();

  for (const [nodeIdx, info] of graph.junctions) {
    const incidents = info.incidents;
    const m = incidents.length;
    if (m < 2) continue;

    for (let i = 0; i < m; i++) {
      const curr = incidents[i];
      const maxDist = curr.wall.thickness * MAX_MITER_FACTOR;

      let leftIntersection: Vec2 | null = null;
      let rightIntersection: Vec2 | null = null;

      if (info.type === 'L') {
        const prev = incidents[(i - 1 + m) % m];
        const next = incidents[(i + 1) % m];

        leftIntersection = geometry.lineIntersection(
          curr.leftLine[0], curr.leftLine[1],
          prev.leftLine[0], prev.leftLine[1]
        );
        rightIntersection = geometry.lineIntersection(
          curr.rightLine[0], curr.rightLine[1],
          next.rightLine[0], next.rightLine[1]
        );
      } else if (info.type === 'T') {
        const angles = incidents.map(inc => inc.angle);
        let legIdx = -1;
        for (let j = 0; j < m; j++) {
          let oppositeFound = false;
          for (let k = 0; k < m; k++) {
            if (j === k) continue;
            if (areOppositeAngles(angles[j], angles[k])) {
              oppositeFound = true;
              break;
            }
          }
          if (!oppositeFound) {
            legIdx = j;
            break;
          }
        }
        if (legIdx === -1) continue;

        if (i === legIdx) {
          const barWalls = incidents.filter((_, idx) => idx !== legIdx);
          const leftCandidates: Vec2[] = [];
          const rightCandidates: Vec2[] = [];
          for (const bar of barWalls) {
            const intLeft = geometry.lineIntersection(
              curr.leftLine[0], curr.leftLine[1],
              bar.leftLine[0], bar.leftLine[1]
            );
            if (intLeft) leftCandidates.push(intLeft);
            const intRight = geometry.lineIntersection(
              curr.rightLine[0], curr.rightLine[1],
              bar.rightLine[0], bar.rightLine[1]
            );
            if (intRight) rightCandidates.push(intRight);
          }
          if (leftCandidates.length) {
            leftIntersection = leftCandidates.reduce((a, b) =>
              vec2.distance(a, curr.leftPoint) < vec2.distance(b, curr.leftPoint) ? a : b
            );
          }
          if (rightCandidates.length) {
            rightIntersection = rightCandidates.reduce((a, b) =>
              vec2.distance(a, curr.rightPoint) < vec2.distance(b, curr.rightPoint) ? a : b
            );
          }
        } else {
          const leg = incidents[legIdx];
          leftIntersection = geometry.lineIntersection(
            curr.leftLine[0], curr.leftLine[1],
            leg.leftLine[0], leg.leftLine[1]
          );
          rightIntersection = geometry.lineIntersection(
            curr.rightLine[0], curr.rightLine[1],
            leg.rightLine[0], leg.rightLine[1]
          );
        }
      } else if (info.type === 'X') {
        let oppositeIdx = -1;
        for (let idx = 0; idx < m; idx++) {
          if (idx === i) continue;
          if (areOppositeAngles(curr.angle, incidents[idx].angle)) {
            oppositeIdx = idx;
            break;
          }
        }
        if (oppositeIdx !== -1) {
          const opp = incidents[oppositeIdx];
          leftIntersection = geometry.lineIntersection(
            curr.leftLine[0], curr.leftLine[1],
            opp.leftLine[0], opp.leftLine[1]
          );
          rightIntersection = geometry.lineIntersection(
            curr.rightLine[0], curr.rightLine[1],
            opp.rightLine[0], opp.rightLine[1]
          );
        }
      }

      // Valida distâncias
      if (leftIntersection && vec2.distance(leftIntersection, curr.leftPoint) > maxDist) {
        leftIntersection = null;
      }
      if (rightIntersection && vec2.distance(rightIntersection, curr.rightPoint) > maxDist) {
        rightIntersection = null;
      }

      // Calcula novo centro, se possível
      let newCenter: Vec2 | null = null;
      if (leftIntersection && rightIntersection) {
        newCenter = [
          (leftIntersection[0] + rightIntersection[0]) / 2,
          (leftIntersection[1] + rightIntersection[1]) / 2,
        ];
      } else if (leftIntersection && !rightIntersection) {
        const wall = curr.wall;
        const dir = vec2.normalize(vec2.sub(wall.end, wall.start));
        const perp: Vec2 = [-dir[1], dir[0]];
        const halfThick = wall.thickness / 2;
        newCenter = [
          leftIntersection[0] - perp[0] * halfThick,
          leftIntersection[1] - perp[1] * halfThick,
        ];
      } else if (rightIntersection && !leftIntersection) {
        const wall = curr.wall;
        const dir = vec2.normalize(vec2.sub(wall.end, wall.start));
        const perp: Vec2 = [-dir[1], dir[0]];
        const halfThick = wall.thickness / 2;
        const rightOffsetDir: Vec2 = [-perp[0], -perp[1]];
        newCenter = [
          rightIntersection[0] - rightOffsetDir[0] * halfThick,
          rightIntersection[1] - rightOffsetDir[1] * halfThick,
        ];
      }

      if (!newCenter) continue;

      // Verifica comprimento mínimo antes de aceitar o ajuste
      const currentEndpoint = curr.side === 'start' ? curr.wall.start : curr.wall.end;
      if (vec2.distance(currentEndpoint, newCenter) <= GEOM_TOL) continue;

      const testStart = curr.side === 'start' ? newCenter : curr.wall.start;
      const testEnd = curr.side === 'end' ? newCenter : curr.wall.end;
      
      // PROTEÇÃO CRÍTICA: nunca permitir parede abaixo de MIN_WALL_LENGTH
      if (!wouldBeValidLength(curr.wall, testStart, testEnd)) {
        // Ajuste rejeitado: deixaria a parede curta demais
        continue;
      }

      let wallAdj = adjustments.get(curr.wallIndex);
      if (!wallAdj) {
        wallAdj = {};
        adjustments.set(curr.wallIndex, wallAdj);
      }
      if (curr.side === 'start') {
        wallAdj.start = newCenter;
      } else {
        wallAdj.end = newCenter;
      }
    }
  }

  return adjustments;
}

// ==================== CLASSE WALL TOPOLOGY (inalterada) ====================
export class WallGraphTopology implements IGraphTopology {
  private walls: Wall[] = [];

  constructor(walls: Wall[]) {
    this.walls = walls;
  }

  updateWalls(walls: Wall[]) {
    this.walls = walls;
  }

  getWallsConnectedToVertex(vertex: Vec2, excludeWallId?: string): Array<{ id: string; start: Vec2; end: Vec2 }> {
    const result: Array<{ id: string; start: Vec2; end: Vec2 }> = [];
    const tol = GEOM_TOL;
    for (const w of this.walls) {
      if (excludeWallId && w.id === excludeWallId) continue;
      const startDist = Math.hypot(w.start[0] - vertex[0], w.start[1] - vertex[1]);
      const endDist = Math.hypot(w.end[0] - vertex[0], w.end[1] - vertex[1]);
      if (startDist < tol || endDist < tol) {
        result.push({ id: w.id, start: [...w.start] as Vec2, end: [...w.end] as Vec2 });
      }
    }
    return result;
  }

  getWallsConnectedToWall(wallId: string): Array<{ id: string; start: Vec2; end: Vec2 }> {
    const wall = this.walls.find(w => w.id === wallId);
    if (!wall) return [];
    const connectedIds = new Set<string>();
    const vertices = [wall.start, wall.end];
    for (const v of vertices) {
      const conns = this.getWallsConnectedToVertex(v, wallId);
      for (const c of conns) connectedIds.add(c.id);
    }
    return this.walls.filter(w => connectedIds.has(w.id)).map(w => ({ id: w.id, start: [...w.start], end: [...w.end] }));
  }

  updateWallGeometry(wallId: string, newStart: Vec2, newEnd: Vec2): void {
    const wall = this.walls.find(w => w.id === wallId);
    if (wall) {
      wall.start = [...newStart] as Vec2;
      wall.end = [...newEnd] as Vec2;
    }
  }

  getJunctionTypeAtVertex(vertex: Vec2): 'L' | 'T' | 'X' | 'none' {
    const graph = buildGraph(this.walls);
    const tol = GEOM_TOL;
    for (const [idx, node] of graph.nodes.entries()) {
      if (Math.hypot(node.position[0] - vertex[0], node.position[1] - vertex[1]) < tol) {
        const junction = graph.junctions.get(idx);
        if (junction) return junction.type;
        break;
      }
    }
    return 'none';
  }
}
