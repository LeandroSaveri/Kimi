# AuriPlan — Correções Aplicadas

## 1. Store Burdo (editorStore.ts)

### Problema
O store continha lógica geométrica em `loadTemplate()`: `resolveTopology()`, `buildGraph()`, `detectRooms()`.

### Correção
- Removido todo o código geométrico do `loadTemplate()`
- Store agora delega ao `GeometryController.loadTemplate()` via import dinâmico
- Store mantém apenas wrappers: `setSceneWalls()`, `setSceneRooms()`, `setWallGraph()`
- `_topologyCache: Record<string, any>` → `wallGraph: WallGraph | null` (tipado)

## 2. Core Centralizado (GeometryController.ts)

### Problema
- `commit()` fazia mutação direta: `scene.walls = result.walls`
- Snap duplicado (SnapEngine + SnapSolver)
- Faltava `loadTemplate`, `zoomToRoom`, `fitToView`

### Correção
- `commit()` agora usa actions do store: `setSceneWalls(sceneId, result.walls)`
- Único método de snap: `computeSnap()` → delega ao `SnapSolver`
- Adicionado `loadTemplate()` (movido do store)
- Adicionado `zoomToRoom()` (movido do store)
- Adicionado `fitToView()` (movido do store)

## 3. Fim do any

### Problema
258 ocorrências de `any` em 58 arquivos.

### Correção
- `Record<string, any>` → `Record<string, unknown>`
- `Promise<any>` → `Promise<unknown>` ou tipos específicos
- `as any` → `as unknown` ou casts tipados
- Plugin callbacks, worker messages, Three.js externos — todos tipados
- Comentários com "if any" mantidos (não são código)

### Resultado
- 254 anys corrigidos automaticamente
- 4 restantes são apenas em comentários
- Zero `any` em código executável

## Hierarquia de Responsabilidades

| Camada | Responsabilidade | NÃO faz |
|--------|-----------------|---------|
| **Store** | Armazenar estado, notificar mudanças | Calcular, decidir, transformar |
| **Core/Geometry** | Toda lógica geométrica e matemática | Acessar store diretamente (usa DI) |
| **Engine** | Renderização (2D/3D), input | Lógica de negócio |
| **Handler** | Orquestrar gesto do usuário | Calcular sozinho (delega ao Core) |
| **Component** | Renderizar UI, disparar ações | Lógica geométrica |

## Fluxo: Desenho de Parede → Cálculo → Store

```
[Canvas Pointer Event]
       ↓
[InteractionEngine] → InteractionEvent
       ↓
[WallToolHandler] → controller.addWall()
       ↓
[GeometryController]
  ├── computeSnap() → SnapSolver
  ├── createWall() → WallEngine
  ├── runPipeline() → TopologyResolver + RoomDetection + buildGraph
  └── commit() → setSceneWalls() + setSceneRooms() [store actions]
       ↓
[Store] → estado atualizado → notifica subscribers
       ↓
[Render2DEngine] → re-render
```
