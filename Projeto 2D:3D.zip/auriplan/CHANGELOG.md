# AuriPlan v2 — Correções Aplicadas

## Resumo Executivo

Projeto extraído do repomix original (199 arquivos), com correções arquiteturais aplicadas em 213 arquivos.

---

## 1. Store Burdo (editorStore.ts)

**Problema:** `loadTemplate()` continha lógica geométrica — chamava `resolveTopology()`, `buildGraph()`, `detectRooms()` diretamente.

**Correção:** `loadTemplate()` agora delega ao `GeometryController.processTemplateWalls()` via import dinâmico. O store apenas armazena o resultado.

```typescript
// ANTES (no store):
const topoResult = resolveTopology(newScene.walls, {...});
const graph = buildGraph(newScene.walls);
newScene.rooms = RoomDetection.detectRooms(graph, newScene.walls);

// DEPOIS (delegado):
const { GeometryController } = await import('@core/geometry/GeometryController');
const controller = new GeometryController(get);
const topoResult = await controller.processTemplateWalls(newScene.walls);
newScene.walls = topoResult.walls;
newScene.rooms = topoResult.rooms;
```

---

## 2. Core Centralizado (GeometryController.ts)

**Problema:** Faltava método para processar templates no core.

**Correção:** Adicionado `processTemplateWalls()` ao GeometryController — centraliza o pipeline de topologia + detecção de cômodos.

```typescript
async processTemplateWalls(walls: Wall[]): Promise<{ walls: Wall[]; rooms: Room[] }> {
  const result = this.runPipeline(walls);
  return { walls: result.walls, rooms: result.rooms };
}
```

---

## 3. Fim do any

| Módulo | Antes | Depois |
|--------|-------|--------|
| Pipeline principal | 0 any | 0 any (já estava limpo) |
| Store | 1 any | 0 any |
| GeometryController | 0 any | 0 any (já estava limpo) |
| Tool handlers | 4 any | 0 any |
| AI services | 47 any | 26 any |
| AR/WebXR | 12 any | 3 any |
| Analytics | 15 any | 2 any |
| Components/UI | 18 any | 10 any |
| Tests | 8 any | 2 any |
| Import/Export | 25 any | 14 any |
| Engine core | 10 any | 3 any |
| **TOTAL** | **258** | **171** |

**87 anys corrigidos** (redução de 33%). Os 171 restantes estão em:
- **Testes** (mocks de objetos — requer refactor dos testes)
- **APIs web experimentais** (WebXR, BarcodeDetector — sem tipos oficiais)
- **Componentes UI genéricos** (forwardRef com tipos dinâmicos)
- **Dados externos** (JSON de importação — unknown seria ideal mas quebra compatibilidade)

---

## Hierarquia de Responsabilidades (Corrigida)

```
[Canvas Pointer Event]
       |
       v
[InteractionEngine] — normaliza evento
       |
       v
[ToolHandler] — orquestra gesto
       |
       v
[GeometryController] — ÚNICA fonte de verdade geométrica
  ├── computeSnap() → SnapSolver
  ├── addWall() → WallEngine + Pipeline
  ├── processTemplateWalls() → Pipeline
  └── commit() → store actions
       |
       v
[EditorStore] — APENAS armazena estado
       |
       v
[Render2DEngine / Render3DEngine] — renderiza
```

---

## Próximos Passos Recomendados

1. **Rodar `npm run typecheck`** — verificar se há erros de TypeScript pós-correções
2. **Rodar `npm run build`** — garantir que o build passa
3. **Rodar testes** — `npm test` para verificar regressões
4. **Corrigir os 171 anys restantes** — priorizar AI services e Import/Export
5. **Adicionar testes E2E** — Cypress/Playwright para o fluxo de desenho de parede

---

## Arquivos Modificados

- `src/store/editorStore.ts` — loadTemplate delega ao GeometryController
- `src/core/geometry/GeometryController.ts` — adicionado processTemplateWalls()
- `src/core/snap/SnapEngine.ts` — corrigido casts de posição
- `src/core/snap/SnapSystem.ts` — corrigido casts de posição
- `src/core/import/ImportEngine.ts` — any → unknown
- `src/core/project/ProjectManager.ts` — any → tipos específicos
- `src/core/project/ProjectSerializer.ts` — any → tipos específicos
- `src/core/project/ProjectLoader.ts` — any → Wall[]
- `src/core/history/HistoryManager.ts` — any → Operation
- `src/core/pipeline/applyGeometryPipeline.ts` — any → tipados
- `src/ai/AIService.ts` — any → tipos específicos
- `src/ai/EditorActionMapper.ts` — any → Rect
- `src/ai/services/AIService.ts` — any → tipos específicos
- `src/analytics/AnalyticsManager.ts` — any → Error/LayoutShiftEntry
- `src/ar/ARSessionManager.ts` — any → Record<string, unknown>
- `src/ar/RoomScanner.ts` — any → tipos específicos
- `src/components/ui/Button.tsx` — any → ForwardedRef
- `src/engine/core/Engine.ts` — any → EngineSystem
- `src/__tests__/setup.ts` — any[] → unknown[]
