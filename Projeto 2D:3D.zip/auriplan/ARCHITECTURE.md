# AuriPlan — Arquitetura Corrigida

## Resumo das 3 Correcoes

### 1. Store Burdo (editorStore.ts)
- **ANTES**: `loadTemplate()` fazia `resolveTopology`, `buildGraph`, `detectRooms` diretamente
- **ANTES**: `_topologyCache: Record<string, any>` — usava `any`
- **ANTES**: `splitWall()` tinha logica geometrica (dividir parede no ponto)
- **ANTES**: `zoomToRoom()` e `fitToView()` calculavam bounds no store
- **DEPOIS**: Apenas wrappers simples — `setSceneWalls()`, `setSceneRooms()`
- **DEPOIS**: `wallGraph: WallGraph | null` — tipado, sem `any`
- **DEPOIS**: `splitWall`, `zoomToRoom`, `fitToView` movidos para `GeometryController`

### 2. Core Centralizado (GeometryController.ts)
- **ANTES**: `commit()` fazia mutacao direta: `scene.walls = result.walls`
- **ANTES**: Snap via `SnapEngine` (duplicado — ja existia `SnapSolver`)
- **ANTES**: `loadTemplate` no store, `zoomToRoom` no store
- **DEPOIS**: `commit()` usa actions do store: `setSceneWalls(sceneId, result.walls)`
- **DEPOIS**: Unico metodo de snap: `computeSnap()` → delega ao `SnapSolver`
- **DEPOIS**: `loadTemplate`, `zoomToRoom`, `fitToView` centralizados aqui
- **DEPOIS**: Recebe `getState` via injecao de dependencia no constructor

### 3. Fim do any (todos os arquivos)
- **ANTES**: `Record<string, any>` no store, `any` em handlers
- **DEPOIS**: Todos os tipos importados de `@/types` ou `@/core`
- **DEPOIS**: `WallToolHandler` tipado com `InteractionEvent`, `WallPreview`, `SnapResult`

---

## Fluxo [Desenho de Parede → Calculo → Store]

```
[Canvas Pointer Event]
       |
       v
[InteractionEngine] normaliza para InteractionEvent
       |
       v
[WallToolHandler] recebe GeometryController INJETADO
       |
       +-- onPointerDown()
       |       |
       |       +-- controller.beginBatch('Draw wall')
       |       +-- controller.computeSnap(point) → SnapResult
       |       +-- controller.addWall(start, end) → AddWallResult
       |               |
       |               v
       |       [GeometryController.addWall]
       |               |
       |               +-- SnapSolver.computeSnap() (ponto final)
       |               +-- WallEngine.createWall()
       |               +-- runGeometryPipeline(walls)
       |               |       |
       |               |       +-- resolveTopology()
       |               |       +-- detectRooms()
       |               |       +-- buildWallGraph() → WallGraph
       |               |       +-- adjustWallJunctions()
       |               |
       |               +-- commit(result)
       |                       |
       |                       v
       |               [Store via actions]
       |               setSceneWalls(sceneId, result.walls)
       |               setSceneRooms(sceneId, result.rooms)
       |               setWallGraph(result.graph)
       |
       +-- onPointerMove()
       |       |
       |       +-- controller.computeSnap(point, startPoint)
       |       +-- controller.updateWallEnd(wallId, snappedPoint)
       |               |
       |               v
       |       [GeometryController.updateWallEnd]
       |               +-- runGeometryPipeline(updatedWalls)
       |               +-- commit(result) → Store
       |
       +-- onPointerUp()
               |
               +-- Valida comprimento minimo
               +-- Se valido: controller.endBatch() → salva historico
               +-- Se invalido: controller.cancelBatch() → descarta
```

---

## Hierarquia de Responsabilidades

| Camada | Responsabilidade | NAO deve fazer |
|--------|-----------------|----------------|
| **Store** | Armazenar estado, notificar mudancas | Calcular, decidir, transformar |
| **Core** | Toda logica geometrica e matematica | Acessar store diretamente (usa DI) |
| **Engine** | Renderizacao (2D/3D), input | Logica de negocio |
| **Handler** | Orquestrar gesto do usuario | Calcular sozinho (delega ao Core) |
| **Component** | Renderizar UI, disparar acoes | Logica geometrica |

---

## Injecao de Dependencia

```typescript
// App.tsx — ponto de montagem
const store = editorStore;
const controller = new GeometryController(() => store.getState());

// Tool handler recebe controller injetado
const wallHandler = new WallToolHandler(controller, eventBus);

// Handler NAO cria instancias isoladas
// ❌ this.geometryController = new GeometryController() // SEM getState!
// ❌ this.snapEngine = new SnapEngine() // Duplicado!
// ✅ this.controller = controller // Injetado
```

---

## Contratos Tipados (Fim do any)

```typescript
// Antes (quebrado)
_topologyCache: Record<string, any>;

// Depois (tipado)
wallGraph: WallGraph | null;

// Antes (quebrado)
function addWall(start: any, end: any): any;

// Depois (tipado)
function addWall(start: Vec2, end: Vec2, thickness?: number): AddWallResult;

// Antes (quebrado)
scene.walls = result.walls; // Mutacao direta

// Depois (tipado)
state.setSceneWalls(sceneId, result.walls); // Action do store
```
